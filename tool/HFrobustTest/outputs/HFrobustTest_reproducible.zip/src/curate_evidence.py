"""Explicit human-reviewed state assignments; never infer evidence from HF size.
Rebuild curated records from the frozen ENSDF source. Review decisions below are
intentional per-state choices, not a keyword-based independent-evidence classifier.
"""
import json
from pathlib import Path
from ensdf import read_archive,nilsson
R=Path(__file__).resolve().parents[1]
D={d['nuclide']['name']:d for d in read_archive(R/'data/raw/ensdf_261001.zip') if d['title'].startswith('ADOPTED')}
# Both configuration and spin/parity have non-alpha-HF support in the quoted J comment.
assignments={
'221Ra':('5/2[633]','Laser spin and measured magnetic moment, with reflection-asymmetric rotor interpretation; configuration remains model dependent.'),
'225Ra':('1/2[631]','Measured laser spin and magnetic moment orbital assignment. Nominal dominant component; Coriolis coupling retained.'),
'229Th':('5/2[633]','Hyperfine spin plus magnetic moment and transfer L(d,t)=2; nominal ground-band assignment.'),
'231Pa':('1/2[530]','EPR/optical spin, E1 parity, independent transfer spectroscopic factors, decoupling parameter and magnetic moment support K=1/2 although J=3/2.'),
'233U':('5/2[633]','Optical/EPR spin and measured magnetic moment support nominal orbital. Band mixing remains separately evaluated, not measured mixing fraction.'),
'235U':('7/2[743]','Measured spin; parity and orbital supported by magnetic dipole and electric quadrupole moments.'),
'237Np':('5/2[642]','Measured spin and magnetic moment support nominal orbital; possible admixtures are not promoted to definite mixing.'),
'241Pu':('5/2[622]','Paramagnetic resonance and measured magnetic moment.'),
'241Am':('5/2[523]','Optical/atomic beam spin and measured magnetic moment orbital assignment.'),
'243Am':('5/2[523]','Hyperfine spin and agreement of measured magnetic moment with orbital calculation.'),
'243Cm':('5/2[622]','EPR spin plus magnetic moment and (d,t) support.'),
'247Cm':('9/2[734]','Independent ground-state EPR and magnetic moment support; do not extend independence automatically to the excited band assigned partly from alpha HF.'),
'251Es':('3/2[521]','Independent 250Cf(alpha,t) spectroscopic factors support the assignment also inferred from favored alpha decay; both arguments are recorded.'),
'253Es':('7/2[633]','Optical spin and magnetic moment configuration assignment.')}
out={}
for n,(orb,reason) in assignments.items():
 l=next(x for x in D[n]['levels'] if x['energy']['value']==0 and not x['energy']['offset'])
 key=n+'@'+l['energy']['raw']
 out[key]={'nilsson':[orb],'evidence':'independent','spin_evidence':'independent','notes':[reason,'Independent here means independent of alpha HF, not model-free orbital measurement.'],'quote':' '.join(l['spin_comments']),'source_dataset':D[n]['id'],'source_url':'https://www.nndc.bnl.gov/ensdf/DatasetFetchServlet?datasource=ensdf&nuc='+n+'&searchType=ensdfIndex','review':'explicit per-state literature-provenance audit, 2026-10-22'}
# A direct spin measurement does not by itself establish a Nilsson orbital.
for n in ['239Pu']:
 l=next(x for x in D[n]['levels'] if x['energy']['value']==0 and not x['energy']['offset'])
 out[n+'@'+l['energy']['raw']]={'spin_evidence':'independent','evidence':'evaluated_unverified','quote':' '.join(l['spin_comments']),'notes':['Atomic beam and E2 gamma support spin/parity; nominal band orbital not independently reviewed.']}
# 2018 electromagnetic strength evidence for particle-octupole-phonon mixing.
l=next(x for x in D['251Fm']['levels'] if x['energy']['raw']=='200.07')
out['251Fm@200.07']={'mixing':True,'mixing_evidence':'independent','evidence':'evaluated_unverified','spin_evidence':'evaluated_unverified','notes':['2018Re07 measured E3/M2 strengths plus particle-phonon interpretation support configuration mixing independently of alpha HF. No verified mixing amplitude. ENSDF 200.07 keV is the matching adopted 5/2+ state; literature 199.7 keV is retained as historical value.','This is not evidence for a change of static equilibrium shape.'],'source_url':'https://doi.org/10.1103/PhysRevC.97.054332','configuration':'nominal ν5/2+[622] with ν9/2−[734] ⊗ octupole-phonon admixture','quote':'B(E3)=18(6) W.u.; B(M2)=3.0(6)×10^-3 W.u.; interpretation based on electromagnetic strength and beyond-mean-field calculations.'}
# External laser data supersede the old provenance, but do not erase ENSDF parentheses.
out['253No@0']={'nilsson':['9/2[734]'],'evidence':'independent','spin_evidence':'independent','notes':['2018 laser hyperfine/magnetic moment data support I=9/2 and gK compatible with 9/2−[734], conditional on prolate shape and moment sign. ENSDF tentative Jπ retained in sensitivity layer.'],'source_url':'https://doi.org/10.1103/PhysRevLett.120.232503','quote':'See Table I and discussion of hyperfine spin and magnetic moments; independent of alpha HF but model-conditioned.'}
(R/'data/state_evidence_overrides.json').write_text(json.dumps(out,ensure_ascii=False,indent=2))
print('reviewed states',len(out))
