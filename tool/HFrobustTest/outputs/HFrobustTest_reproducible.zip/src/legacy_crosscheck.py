"""Read-only crosscheck against preserved HFdistr ground-state inventory."""
import csv,json,math,hashlib,sys
from pathlib import Path
from collections import Counter
from build import ROOT,OUT,load_methods,csvsave

def cleanrows(p):
 with p.open(encoding='utf-8-sig',newline='') as f:return [{k.strip():(v or '').strip() for k,v in r.items() if k} for r in csv.DictReader(f,skipinitialspace=True)]
def number(v):
 try:return float(v)
 except (ValueError,TypeError):return None

def main():
 legacy=Path(sys.argv[1]) if len(sys.argv)>1 else ROOT/'data/legacy'
 inv=legacy/'ackermann_ground_states.csv'; previous=legacy/'hf_results_wide.csv'
 rows=cleanrows(inv); old=cleanrows(previous); payload=json.loads((OUT/'database.json').read_text());tr=payload['transitions'];cross=[]
 for i,r in enumerate(rows):
  n=r['isotope']; candidates=[t for t in tr if t['A']==int(r['A']) and t['Z']==int(r['Z'])]
  # Only propose ground-state candidates for a blank legacy state label. No
  # assignment is made solely because Q or a half-life happens to be close.
  if not r.get('state_label'):candidates=[t for t in candidates if t['Ei_keV']==0 and t['Ei_raw'] in ['0','0.0','0.00','0.000']]
  ta=number(r.get('T_alpha_half_s'));q=number(r.get('Qalpha_MeV'))
  cross.append({'legacy_row':i+2,'parent':n,'legacy_state_label':r.get('state_label'),'legacy_Q_MeV':q,'legacy_Talpha_s':ta,'candidate_count':len(candidates),'status':'no_snapshot_parent_state' if not candidates else 'requires_final_state_resolution' if len(candidates)>1 else 'single_candidate_not_automatically_equivalent','candidate_ids':[t['id'] for t in candidates],'Qif_minus_legacyQ_MeV':[t['Qalpha_MeV']-q if t['Qalpha_MeV'] is not None and q else None for t in candidates],'line_Tpartial_over_legacy_Talpha':[t['T_partial_s']/ta if t['T_partial_s'] and ta else None for t in candidates],'note':'Legacy T_alpha is already alpha partial half-life; never divide it again by b_alpha. Ground-state mass Q and line Q_if are not interchangeable. Multiple line candidates are not duplicate legacy observations.'})
 mapping={'DZR':'dzr','Ismail2022':'ismail2022_formula_e','Qi2009_UDL':'qi2009_udl','Viola_Seaborg':'viola_seaborg','Xu2022':'xu2022_unified','E_Rurarz':'e_rurarz'};reg=[]
 for m in load_methods():
  if m['name'] not in mapping:continue
  diffs=[]
  for r in old:
   before=number(r.get('log10_Tcalc_s__'+mapping[m['name']]))
   if before is None:continue
   now=m['fn'](int(r['A']),int(r['Z']),float(r['Qalpha_MeV']),0)
   diffs.append(abs(now-before))
  reg.append({'method':m['name'],'n_comparisons':len(diffs),'max_abs_log10_difference':max(diffs) if diffs else None,'passed_rounding_tolerance_1e_8':bool(diffs) and max(diffs)<1e-8})
 result={'legacy_inventory_records':len(rows),'legacy_numeric_results':len(old),'source_files':[{'file':p.name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in [inv,previous]],'crosscheck_status_counts':dict(Counter(r['status'] for r in cross)),'numeric_regression':reg,'crosschecks':cross,'legacy_Xu_note_correction':'Legacy dashboard calls the whole Xu formula outside-domain at Z>90. Author paper applies to superheavy nuclei; only piecewise C=0 outside the two listed regions remains a local convention.'}
 (ROOT/'data/legacy_crosscheck.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));csvsave(OUT/'legacy_crosscheck.csv',cross);csvsave(OUT/'formula_regression.csv',reg)
 print(json.dumps({k:v for k,v in result.items() if k!='crosschecks'},ensure_ascii=False,indent=2))
if __name__=='__main__':main()
