"""Regenerate the focused Pu-239 audit from the delivered numerical payload."""
import json
from build import OUT,csvsave

p=json.loads((OUT/'database.json').read_text())
ti={t['id']:t for t in p['transitions']}
t=ti['ensdf-412f45083d69-a1']
rr=[r for r in p['results'] if r['transition_id']==t['id']]
lines=['# 239Pu → 235U：70.77% 支路核查（2026-10-26）','',
'结论：原计算没有把 γ 的 10⁻⁶ 乘入 α 强度，七式 HF 均不是高阻碍值。修复的是 Adopted 核态关联失败导致的末态轨道、带头身份和标签缺失；没有修改公式、IA、半衰期或 Q。','',
'## 逐线输入','',
'| 字段 | 本地输入及处理 |','|---|---|',
f"| ID | `{t['id']}` |",
f"| 初末核 | {t['parent']} → {t['daughter']}，不是 241Pu |",
f"| Jπ、轨道 | {t['Ji']} → {t['Jf']}；{t['initial_nilsson']} → {t['final_nilsson']} |",
f"| 末态能量 | 衰变表 {t['Ef_raw']} keV；Adopted {t['final_adopted_energy_record']['raw']} keV，双方误差均 0.0004 keV |",
f"| IA | {t['I_input_record']['raw']} ± 0.14 % → {t['I_alpha']} ± 0.0014 |",
f"| N 记录 | NR=10⁻⁶，NT=10⁻⁶，BR=1，NB空白；NR/NT未进入α计算 |",
f"| 单线概率 | bα × Iif = {t['br']} |",
f"| 总半衰期 | {t['T_total_s']:.12g} s = 24110 y |",
f"| 单线部分半衰期 | {t['T_partial_s']:.12g} s = {t['T_partial_s']/31557600:.8g} y |",
f"| Eα | {t['Ealpha_MeV']:.8f} MeV |",
f"| Qif | Eα × 239/235 = {t['Qalpha_MeV']:.10f} MeV（本地反冲约定） |",
f"| 质量差交叉检查 | Qgs − Ef = {t['Q_ground_MeV']-t['Ef_keV']/1000:.10f} MeV，仅供对照，未替换主输入 |",
'| 选择定则 | 1/2⁺ → 1/2⁺ 仅允许 l=0；有角动量项的 HF(0) 与 HF(lmin) 相同 |','',
'## 七式本地原版结果','',
'HF = Tif(exp)/Tcalc。未重新拟合，也未将 ENSDF HF 强制作为任何公式的计算结果。','',
'| 公式 | 模式 | Tcalc / s | HF |','|---|---|---:|---:|']
for r in rr:
 lines.append(f"| {r['method']} | {r['mode']} | {r['Tcalc_s']:.9g} | {r['HF']:.9g} |")
lines += ['', '## 核态匹配修复与相邻支路', '',
'旧匹配的最低窗口为 0.08 keV，因而同时纳入 0 keV 基态与 0.0760 keV 异能态；两者都不与 0.0765 keV 完全相等，程序保留为未匹配，而非选成基态。新增规则只在误差支持唯一候选时消除这种歧义：两份异能态能量之差为 0.0005 keV，小于合成误差的 3 倍；基态不满足。无误差的其他竞争能级、仍有多候选及不同能量偏移符号均不强制匹配。', '',
'| 逐线 ID | Ef / keV | Jf | 末态轨道 | Royer HF | 说明 |',
'|---|---:|---|---|---:|---|']
for suffix,note in [('a0','0-keV基态；IA与HF为系统学估计，非这条70.77%实测线'),('a1','低能异能态带头；本次修复的favored参考线'),('a36','独立的β振动激发带头；相同名义Nilsson轨道不等于相同完整波函数')]:
 x=ti['ensdf-412f45083d69-'+suffix]
 r=next(r for r in p['results'] if r['transition_id']==x['id'] and r['method']=='Royer')
 lines.append(f"| {x['id']} | {x['Ef_raw']} | {x['Jf']} | {x['final_nilsson']} | {r['HF']:.6g} | {note} |")
lines += ['', '769.27 keV 支路按目前“相同内禀准粒子轨道、双带头”的口径仍在评估层 same_intrinsic 中；其转动带原文明确包含 β 振动，不能把它与低能异能态视为同一个终态，也不能将该标签解读为完整波函数相同。', '',
'## 证据层与使用限制','',
'该线现为 same_intrinsic（两端带头），用于评估指认敏感性层。当前 Adopted 自旋指认注释引用了 favored α 衰变，因此未由本次低 HF 自动提升为独立谱学主标定。研究纯组态标定时还需另行复核独立证据。', '',
'ENSDF 列出的参考 HF=2.76 属于其穿透计算与半径约定；衰变表指定 r0(235U)=1.5122，不能要求七套经验半衰期公式与之完全一致。', '',
'## 可追溯来源','',
f"- [NNDC 239Pu α 衰变表]({t['source_url']})；[本地冻结文本](sources/{t['dataset_id']}.txt)。",
'- [ENSDF 手册，Alpha Record 第12节](https://www.nndc.bnl.gov/ensdf/ensdf-manual.pdf)：IA 为总 α 衰变的百分数；E 为 α 粒子能量，单位 keV。',
'- [235U Adopted 冻结文本](sources/ensdf-acc2e6b6fd6a.txt)。',
'- `pu239_favored_results.csv` 为此线全部10条公式/角动量结果；原始输入与新增 N 记录、Adopted 能量字段同时存于 JSON/CSV/SQLite。', '']
(OUT/'PU239_AUDIT.md').write_text('\n'.join(lines),encoding='utf-8')
csvsave(OUT/'pu239_favored_results.csv',rr)
print('Pu-239 focused audit and formula table regenerated.')
