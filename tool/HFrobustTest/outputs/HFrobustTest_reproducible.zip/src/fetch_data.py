"""Download documented NNDC resources. Resume from immutable local raw caches."""
from pathlib import Path
from urllib.request import Request, urlopen
from urllib.parse import urlencode
from concurrent.futures import ThreadPoolExecutor, as_completed
import json, time, hashlib, argparse

ROOT=Path(__file__).resolve().parents[1]
RAW=ROOT/'data'/'raw'
API='https://www.nndc.bnl.gov/ensdf-api/'

def get(url):
    for attempt in range(4):
        try:
            with urlopen(Request(url,headers={'User-Agent':'HFrobustTest academic nuclear-data analysis; Python urllib'}),timeout=60) as r:
                return r.read()
        except Exception:
            if attempt==3: raise
            time.sleep(1+attempt*2)

def cached(name, endpoint, params=None):
    path=RAW/(name+'.json')
    if path.exists(): return name,len(json.loads(path.read_text()).get('results',[]))
    url=API+endpoint+('?' + urlencode(params) if params else '')
    urls=[]; items=[]
    while url:
        d=json.loads(get(url)); urls.append(url)
        if 'results' not in d:
            path.write_text(json.dumps(d,ensure_ascii=False));return name,1
        items.extend(d['results']);url=d.get('meta',{}).get('next')
    path.write_text(json.dumps({'urls':urls,'results':items},ensure_ascii=False))
    return name,len(items)

def main():
    RAW.mkdir(parents=True,exist_ok=True)
    jobs=[('release','meta/release',None),('all_alpha_datasets','datasets',{'document-type':'alphaDecay','limit':500,'include-comments':'true'}),
          ('all_alpha_decays','decays',{'document-type':'alphaDecay','limit':500,'include-comments':'true','include-evaluator-input':'true'})]
    for z in range(87,119):
        if z<=116: jobs.append((f'alphas_z{z}','alphas',{'z':z,'document-type':'alphaDecay','limit':500,'include-comments':'true','include-evaluator-input':'true'}))
        jobs.append((f'adopted_levels_z{z}','levels',{'z':z,'document-type':'adopted','limit':500,'include-comments':'true','include-evaluator-input':'true'}))
        jobs.append((f'sequences_z{z}','sequences',{'z':z,'document-type':'adopted','limit':500}))
    failures=[]
    with ThreadPoolExecutor(max_workers=4) as pool:
        futures={pool.submit(cached,*j):j[0] for j in jobs}
        for f in as_completed(futures):
            try: print(*f.result(),flush=True)
            except Exception as e: failures.append({'resource':futures[f],'error':str(e)}); print('FAILED',futures[f],str(e),flush=True)
    (RAW/'fetch_failures.json').write_text(json.dumps(failures,indent=2))
    # The October archive is checked separately against the API August release.
    url='https://www.nndc.bnl.gov/ensdfarchivals/distributions/files.json'
    p=RAW/'archive_files.json'
    if not p.exists(): p.write_bytes(get(url))
    catalog=json.loads(p.read_text());print('ARCHIVE',catalog.get('latest'),flush=True)
    latest=catalog.get('latest',{});year=str(latest.get('year',''))
    for filename in latest.get('files',[]):
        if filename.endswith('.zip'):
            p=RAW/filename
            if not p.exists():
                u=f'https://www.nndc.bnl.gov/ensdfarchivals/distributions/dist{year[-2:]}/{filename}'
                p.write_bytes(get(u))
            print('ARCHIVE_SAVED',filename,p.stat().st_size,flush=True)
    manifest={p.name:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in RAW.iterdir() if p.is_file()}
    (ROOT/'data'/'raw_manifest.json').write_text(json.dumps(manifest,indent=2))
    if failures: raise SystemExit(f'{len(failures)} resources failed; rerun to resume.')

if __name__=='__main__':main()
