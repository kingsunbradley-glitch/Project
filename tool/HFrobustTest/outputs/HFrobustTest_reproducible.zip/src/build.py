"""Rebuild the frozen, transition-resolved HF database and offline viewer."""
from __future__ import annotations
import csv,json,math,re,sqlite3,hashlib,importlib.util,sys,shutil,statistics
from pathlib import Path
from collections import defaultdict,Counter
from urllib.parse import urlencode
import numpy as np
from ensdf import read_archive,parse_decay,quantity,nucleus,nilsson,allowed_l,spins,SYMBOLS,is_limit

ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'outputs';DATA=ROOT/'data';RAW=DATA/'raw'
LABELS={'same_intrinsic':'同组态带头 → 带头','same_band':'同组态转动带成员跃迁','nilsson_changed':'Nilsson 轨道改变','multi_qp_changed':'多准粒子组态改变','shape_changed':'有独立证据的形变变化','configuration_mixing':'明显组态混合','parity_change':'初末态宇称改变','spin_flip':'带头间 Λ−K 改变','unknown':'证据不足'}
LABEL_POLICY={'version':'2026-10-26-spin-flip-bandheads','same_intrinsic':'相同内禀准粒子组态，且初态与末态均有带头指认；不包含转动带其他成员。','same_band':'同组态对应转动带的跃迁，至少一端为非带头成员；与 same_intrinsic 互斥。','spin_flip':'两端均为带头，且有唯一可辨认的单准粒子轨道与 Λ−K 改变；非带头成员及带头未确定者不纳入。','parity_change':'初末态宇称改变；不要求带头，可包含涉及转动带成员的 α 跃迁。','band_role_rule':'自动判定限于评估资料中明确关联到同一名义 Nilsson 轨道的带：单一 Jπ 与轨道宇称一致时，J=K 为带头，J>K 为转动成员。没有带关联、Jπ 多候选或相互矛盾时保留 unknown；不由基态、相同 Jπ、l=0 或 HF 推定带头。暂定指认保留证据状态。'}
METHODS=[('Royer','calc_dzr_poenaru_format.py',False),('DZR','calc_dzr_poenaru_format.py',True),('Ismail2022','calc_ismail2022_formulaE.py',True),('Qi2009_UDL','calc_qi2009_udl.py',False),('Viola_Seaborg','calc_viola_seaborg.py',False),('Xu2022','calc_xu2022_unified.py',True),('E_Rurarz','calc_poenaru_E. Rurarz_format.py',False)]

def jsave(path,v):path.write_text(json.dumps(v,ensure_ascii=False,allow_nan=False,separators=(',',':')),encoding='utf-8')
def readj(path,default=None):return json.loads(path.read_text()) if path.exists() else default
def flat(v):return json.dumps(v,ensure_ascii=False,separators=(',',':')) if isinstance(v,(dict,list)) else v
def csvsave(path,rows,fields=None):
    if not rows and not fields:return
    fields=fields or list(dict.fromkeys(k for r in rows for k in r))
    with path.open('w',newline='',encoding='utf-8-sig') as f:
        w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows({k:flat(r.get(k)) for k in fields} for r in rows)
def val(q):return (q or {}).get('value')
def positive(x):return x is not None and math.isfinite(x) and x>0
def nuclide_url(n):return 'https://www.nndc.bnl.gov/ensdf/DatasetFetchServlet?'+urlencode({'datasource':'ensdf','nuc':n,'nucmass':'isNuc','searchType':'ensdfIndex'})
def decay_url(d):return 'https://www.nndc.bnl.gov/nudat3/getdecaydataset.jsp?'+urlencode({'nucleus':d['nuclide']['name'].upper(),'dsid':d['title'].lower()})
def state_key(n,e):return n+'@'+str(e.get('raw','?'))

def match_level(ds,energy):
    if not ds or val(energy) is None:return None
    e=val(energy);c=[]
    for l in ds['levels']:
        q=l['energy']
        if val(q) is None or q.get('offset')!=energy.get('offset'):continue
        tol=max(.08,3*math.hypot(q.get('plus') or 0,energy.get('plus') or 0))
        if abs(val(q)-e)<=min(tol,2.):c.append(l)
    if len(c)==1:return c[0]
    exact=[l for l in c if abs(val(l['energy'])-e)<1e-5]
    if len(exact)==1:return exact[0]
    # The legacy 80-eV search window can contain both a ground state and a
    # low-lying isomer. Resolve such a tie only with quoted uncertainties,
    # never by rounding the isomer to zero or choosing the nearest blindly.
    compatible=[]
    if not energy.get('qualifier') and energy.get('plus') is not None:
        for level in c:
            q=level['energy']
            if q.get('qualifier'):return None
            # A zero-energy ground reference is exact by convention; do not
            # assume zero uncertainty for another unquoted level energy.
            if q.get('plus') is None and val(q)!=0:return None
            sigma=math.hypot(q.get('plus') or 0,energy['plus'])
            if sigma>0 and abs(val(q)-e)<=min(3*sigma,2.):compatible.append(level)
    return compatible[0] if len(compatible)==1 else None

def band_role(level,orbs,band,override,configuration_evidence,spin_evidence):
    """Identify the spin-K bandhead only with an explicit state-to-band link.

    In particular, a J>K ground state in a decoupled K=1/2 band is not promoted
    to a spin-K bandhead merely because it has the lowest observed energy.
    """
    def result(role,basis,evidence='unresolved'):
        return {'band_role':role,'band_role_basis':basis,'band_role_evidence':evidence}
    if override.get('band_role') in ['bandhead','rotational_member'] and override.get('band_role_basis'):
        return result(override['band_role'],override['band_role_basis'],override.get('band_role_evidence','evaluated'))
    if not level or len(orbs)!=1:
        return result('unknown','没有唯一的核态与单准粒子轨道指认。')
    orb=orbs[0]
    # Other orbitals can occur in explanatory prose about decay destinations.
    # Only the nominal band heading establishes the state-to-band association.
    header=re.sub(r'\bg\.s\.', 'ground state',band,flags=re.I)
    header=re.split(r'\.|;|\b(?:Low hindrance|Main configuration|Strongly|However|From)\b',header,maxsplit=1,flags=re.I)[0]
    band_orbs=nilsson(header)
    if not band_orbs or band_orbs[0]['orbital']!=orb['orbital']:
        return result('unknown','现有记录缺少该核态与对应 Nilsson 转动带的明确关联；相同轨道本身不证明是带头。')
    ss=level.get('spins',[])
    if len(ss)!=1:
        return result('unknown','Jπ 未定或有多个候选，不能唯一确定带头/转动成员。')
    spin=ss[0]
    if spin['parity']!=orb['parity'] or spin['j']<orb['k']:
        return result('unknown','核态 Jπ 与名义轨道 Kπ 不一致，不能据此确定带角色。')
    tier='tentative' if spin.get('tentative') or configuration_evidence=='tentative' else 'independent' if configuration_evidence==spin_evidence=='independent' else 'evaluated'
    role='bandhead' if spin['j']==orb['k'] else 'rotational_member'
    return result(role,f"评估带关联：{orb['orbital']}；J={spin['j']:g}，K={orb['k']:g}，π={spin['parity']}；"+('J=K 的带头成员。' if role=='bandhead' else 'J>K 的非带头转动成员。'),tier)

def state_structure(n,l,ds,overrides):
    if not l:return {'nilsson':[],'nilsson_candidates':[],'band':'','configuration':'','evidence':'unreviewed','spin_evidence':'unreviewed','mixing':False,'notes':[],'source_url':nuclide_url(n),**band_role(None,[],'',{},'unreviewed','unreviewed')}
    band=l.get('band_description','');jt=' '.join(l.get('spin_comments',[]));ct=' '.join(l.get('comments',[]));continuations=' '.join(l.get('continuations',[]))
    # A band heading supplies its nominal orbital; subsequent prose may mention
    # other bands and must not silently be treated as a pure configuration.
    head=band.split('.')[0].split(';')[0]
    orbs=nilsson(head)
    if not orbs:
        cm=re.search(r'(?:configuration|orbital assignment)[^.$\n]{0,180}',jt,re.I)
        if cm:orbs=nilsson(cm[0])
    candidates=nilsson(band+' '+jt)
    mixing=bool(re.search(r'(strongly.*(?:mix|coupl)|mixture of|significant admixture|strong Coriolis)',band+' '+jt,re.I))
    ambiguous=any(x in head.lower() for x in ['possible','?','tentative','+ 1/2','~#','~x'])
    hf_based=bool(re.search(r'(favou?red|hindrance|from.*\|a.decay|\bHF\b)',jt,re.I))
    evidence='hf_dependent' if hf_based else 'evaluated_unverified'
    if ambiguous:evidence='tentative'
    # Independent status is ONLY granted by the reviewed overrides file.
    o=overrides.get(state_key(n,l['energy']),{})
    if o.get('nilsson') is not None:orbs=[x for s in o['nilsson'] for x in nilsson(s)]
    if o.get('evidence'):evidence=o['evidence']
    spin_evidence=o.get('spin_evidence','hf_dependent' if hf_based else 'evaluated_unverified')
    if o.get('mixing') is not None:mixing=o['mixing']
    return {'nilsson':orbs,'nilsson_candidates':candidates,'band':band,'configuration':o.get('configuration',head),'evidence':evidence,'spin_evidence':spin_evidence,'mixing':mixing,'notes':o.get('notes',[]),'quote':jt,'source_url':o.get('source_url',nuclide_url(n)),'references':sorted(set(re.findall(r'\b(?:19|20)\d{2}[A-Z][a-zA-Z]\d{2}\b',jt))), 'override':o,**band_role(l,orbs,band,o,evidence,spin_evidence),'band_role_source_url':nuclide_url(n),'band_role_source_dataset':ds['id'] if ds else None,'band_role_raw_level':l.get('raw_line')}

def branch_from_adopted(l):
    if not l:return None
    for line in l.get('continuations',[]):
        m=re.search(r'%A\s*(=|LE|LT|GE|GT)\s*([0-9.Ee+\-]+)(?:\s+([0-9]+))?',line)
        if m:return quantity(m[2],m[3] or (m[1] if m[1]!='=' else ''),.01)
    return None

def make_transitions():
    datasets=read_archive(RAW/'ensdf_261001.zip');adopted={d['nuclide']['name']:d for d in datasets if d['title'].startswith('ADOPTED')}
    overrides=readj(DATA/'state_evidence_overrides.json',{})
    states={};trs=[];sources=[];coverage=[];audits=[]
    for ds in datasets:
        if ' A DECAY' not in ds['title']:continue
        parents,norms,alphas=parse_decay(ds)
        if len(parents)!=1 or not parents[0]['nuclide']:continue
        p=parents[0];nu=p['nuclide'];pn=nu['name'];dn=ds['nuclide']['name']
        if not 89<=nu['z']<=118:continue
        adp=adopted.get(pn);adf=adopted.get(dn);pl=match_level(adp,p['energy'])
        pstr=state_structure(pn,pl,adp,overrides)
        ji=(pl['spins'] if pl and pl['spins'] else p['spins']);ji_raw=(pl['jpi_raw'] if pl and pl['spins'] else p['jpi_raw'])
        tq=pl['half_life'] if pl and positive(val(pl['half_life'])) else p['half_life']
        br=norms[0]['br'] if len(norms)==1 and positive(val(norms[0]['br'])) else (branch_from_adopted(pl) or quantity(''))
        brsource='decay normalization N.BR' if len(norms)==1 and positive(val(norms[0]['br'])) else 'adopted %A' if val(br) else 'missing'
        pid=ds['id']+'-parent'
        states[pid]={'id':pid,'nuclide':pn,'a':nu['a'],'z':nu['z'],'energy':p['energy'],'jpi':ji_raw,'spins':ji,'structure':pstr,'half_life':tq,'source_dataset':adp['id'] if pl else ds['id']}
        sources.append({'id':ds['id'],'title':ds['title'],'daughter':dn,'revision':ds['revision'],'cutoff':ds['cutoff'],'url':decay_url(ds),'sha256':ds['sha256'],'snapshot':'ensdf_261001.zip','raw_file':'sources/'+ds['id']+'.txt'})
        (OUT/'sources'/f'{ds["id"]}.txt').write_text('\n'.join(ds['lines']),encoding='utf-8')
        coverage.append({'parent':pn,'Z':nu['z'],'A':nu['a'],'dataset_id':ds['id'],'dataset':ds['title'],'alpha_records':len(alphas),'revision':ds['revision'],'status':'enumerated'})
        for a in alphas:
            f=a['level'];fl=match_level(adf,f['energy']) if f else None
            fstr=state_structure(dn,fl or f,adf if fl else ds,overrides)
            jf=(fl['spins'] if fl and fl['spins'] else f['spins'] if f else []);jfraw=(fl['jpi_raw'] if fl and fl['spins'] else f['jpi_raw'] if f else '')
            fid=ds['id']+'-final-'+str(f['index']) if f else ds['id']+'-unplaced-'+str(a['index'])
            states[fid]={'id':fid,'nuclide':dn,'a':nu['a']-4,'z':nu['z']-2,'energy':f['energy'] if f else quantity(''),'jpi':jfraw,'spins':jf,'structure':fstr,'source_dataset':adf['id'] if fl else ds['id']}
            flags=[];eq=a['energy'];iq=a['intensity'].copy();E=val(eq)
            alpha_norm=norms[0]['nb'] if len(norms)==1 and positive(val(norms[0]['nb'])) else quantity('1','0')
            if val(alpha_norm)!=1 and val(iq) is not None:
                raw_i=val(iq);iq['value']=raw_i*val(alpha_norm)
                for side in ['plus','minus']:
                    terms=[(iq.get(side)*val(alpha_norm))**2] if iq.get(side) is not None else []
                    if alpha_norm.get(side) is not None:terms.append((raw_i*alpha_norm[side])**2)
                    iq[side]=math.sqrt(sum(terms)) if terms else None
                iq['normalization_multiplier']=val(alpha_norm)
                flags.append('explicit_alpha_normalization')
                if alpha_norm.get('plus') is None:flags.append('incomplete_uncertainty')
            q=E*nu['a']/(nu['a']-4) if positive(E) else None
            qeplus=(eq.get('plus')*nu['a']/(nu['a']-4)) if eq.get('plus') is not None else None
            qeminus=(eq.get('minus')*nu['a']/(nu['a']-4)) if eq.get('minus') is not None else None
            qsrc='Ealpha × A/(A−4); local recoil convention'
            if q is None and val(p['q_ground']) is not None and f and val(f['energy']) is not None and val(p['energy']) is not None and not p['energy'].get('offset') and not f['energy'].get('offset'):
                q=val(p['q_ground'])+(val(p['energy'])-val(f['energy']))/1000.;qsrc='Qgs + Ei − Ef'
                qeplus=math.sqrt(sum((v or 0)**2 for v in [p['q_ground'].get('plus'),(p['energy'].get('plus') or 0)/1000,(f['energy'].get('plus') or 0)/1000]));qeminus=qeplus;flags.append('q_from_levels')
            prob=val(br)*val(iq) if positive(val(br)) and positive(val(iq)) else None
            T=val(tq);partial=T/prob if positive(T) and positive(prob) else None
            if not positive(val(br)):flags.append('missing_alpha_branch')
            if not positive(val(iq)):flags.append('missing_line_intensity')
            if prob is not None and prob>1+1e-6:flags.append('branch_gt_one');partial=None
            if not positive(q):flags.append('missing_Q')
            if not positive(T):flags.append('missing_half_life')
            if not ji or not jf:flags.append('missing_Jpi')
            if len(ji)>1 or len(jf)>1:flags.append('multiple_Jpi')
            if any(s['tentative'] for s in ji+jf):flags.append('tentative_Jpi')
            if not f:flags.append('unplaced_alpha')
            if f and f['existence']=='?':flags.append('uncertain_final_state')
            if a['existence']=='?':flags.append('uncertain_alpha')
            if a['existence']=='S':flags.append('expected_alpha')
            qrecord=eq if positive(E) else p['q_ground']
            if any(qt.get('qualifier') for qt in [qrecord,iq,br,tq]):flags.append('qualified_measurement')
            if qrecord.get('qualifier') in ['calculated','systematics']:flags.append('estimated_Q')
            if any(qt.get('plus') is None for qt in [qrecord,iq,tq]) or (val(br)!=1 and br.get('plus') is None):flags.append('incomplete_uncertainty')
            candidates=[]
            for si in ji:
                for sf in jf:
                    ls=allowed_l(si['j'],si['parity'],sf['j'],sf['parity'])
                    candidates.append({'ji':si['j'],'pi':si['parity'],'jf':sf['j'],'pf':sf['parity'],'allowed':ls,'lmin':min(ls) if ls else None,'tentative':si['tentative'] or sf['tentative']})
            if candidates and all(not c['allowed'] for c in candidates):flags.append('no_allowed_l')
            es=([pstr['evidence'],fstr['evidence']]);independent=all(x=='independent' for x in es)
            labels=[];label_evidence={}
            def tag(k,evidence):
                if k not in labels:labels.append(k);label_evidence[k]=evidence
            po=pstr['nilsson'];fo=fstr['nilsson']
            if len(po)==len(fo)==1:
                roles=[pstr['band_role'],fstr['band_role']]
                role_independent=independent and all(s['band_role_evidence']=='independent' for s in [pstr,fstr])
                if po[0]['orbital']==fo[0]['orbital']:
                    if roles==['bandhead','bandhead']:
                        tag('same_intrinsic','independent' if role_independent else 'evaluated')
                    elif 'rotational_member' in roles and 'unknown' not in roles:
                        tag('same_band','independent' if role_independent else 'evaluated')
                else:tag('nilsson_changed','independent' if independent else 'evaluated')
                if roles==['bandhead','bandhead'] and po[0]['sigma_user']!=fo[0]['sigma_user']:
                    tag('spin_flip','independent' if role_independent else 'evaluated')
            if pstr['mixing'] or fstr['mixing']:
                mx=[s for s in [pstr,fstr] if s['mixing']]
                tag('configuration_mixing','independent' if all(s.get('override',{}).get('mixing_evidence')=='independent' for s in mx) else 'evaluated')
            if ji and jf and all(c['pi']!=c['pf'] for c in candidates):
                spin_ind=all(s['spin_evidence']=='independent' for s in [pstr,fstr])
                tag('parity_change','independent' if spin_ind else 'evaluated')
            if not labels:tag('unknown','unresolved')
            if any(x in ['hf_dependent','tentative'] for x in es):flags.append('structure_assignment_not_independent')
            t={'id':ds['id']+'-a'+str(a['index']),'dataset_id':ds['id'],'parent_state_id':pid,'final_state_id':fid,'parent':pn,'daughter':dn,'Z':nu['z'],'N':nu['n'],'A':nu['a'],'parity_class':('e' if nu['z']%2==0 else 'o')+('e' if nu['n']%2==0 else 'o'),'region':'actinide' if nu['z']<=103 else 'superheavy','chain_id':f'{nu["n"]-nu["z"]}:{nu["z"]%2}', 'Ei_keV':val(p['energy']),'Ei_raw':p['energy']['raw'],'Ef_keV':val(f['energy']) if f else None,'Ef_raw':f['energy']['raw'] if f else '', 'Ji':ji_raw,'Jf':jfraw,'Ji_original':p['jpi_raw'],'Jf_original':f['jpi_raw'] if f else '', 'initial_nilsson':'; '.join(x['orbital'] for x in po),'final_nilsson':'; '.join(x['orbital'] for x in fo),'initial_K':po[0]['k'] if len(po)==1 else None,'final_K':fo[0]['k'] if len(fo)==1 else None,'initial_Lambda':po[0]['lambda'] if len(po)==1 else None,'final_Lambda':fo[0]['lambda'] if len(fo)==1 else None,'initial_spin_user':po[0]['sigma_user'] if len(po)==1 else None,'final_spin_user':fo[0]['sigma_user'] if len(fo)==1 else None,'Qalpha_MeV':q,'Q_err_plus':qeplus,'Q_err_minus':qeminus,'Q_source':qsrc,'Q_ground_MeV':val(p['q_ground']),'Ealpha_MeV':E,'T_total_s':T,'T_total_record':tq,'T_decay_dataset_s':val(p['half_life']),'T_source':'adopted' if pl and tq is pl['half_life'] else 'decay P','b_alpha':val(br),'b_alpha_record':br,'b_alpha_source':brsource,'I_alpha':val(iq),'I_record':iq,'br':prob,'T_partial_s':partial,'J_candidates':candidates,'labels':labels,'label_evidence':label_evidence,'flags':flags,'source_url':decay_url(ds),'source_revision':ds['revision'],'comments':a['comments'],'raw_alpha':a['raw_line'],'evaluated_HF_reference_only':a['evaluated_hf'],'preferred':True,'observed_status':'limit_or_uncertain' if any(x in flags for x in ['qualified_measurement','uncertain_alpha','uncertain_final_state']) else 'recorded'}
            trs.append(t)
            t['Q_input_record']=qrecord
            t['I_input_record']=a['intensity']
            t['alpha_normalization_record']=alpha_norm
            t['normalization_records']=norms
            t['final_adopted_energy_record']=fl['energy'] if fl else None
            t['alpha_existence_code']=a['existence']
            t['data_origin']='ENSDF'
            if pl and positive(val(p['half_life'])) and positive(T) and abs(math.log10(T/val(p['half_life'])))>.01:
                audits.append({'transition_id':t['id'],'check':'adopted_vs_decay_half_life','old':val(p['half_life']),'selected':T,'note':'matched current Adopted state used; original P value retained'})
    # Potential repeated records are retained, but only one exact duplicate can enter a range.
    groups=defaultdict(list)
    for t in trs:groups[(t['parent'],t['Ei_raw'],t['daughter'],t['Ef_raw'],t['Ealpha_MeV'])].append(t)
    for ts in groups.values():
        if len(ts)>1:
            for t in sorted(ts,key=lambda x:(x['source_revision'],x['dataset_id']),reverse=True)[1:]:t['preferred']=False;t['flags'].append('duplicate_alternative')
    # Preserve adopted source text for every referenced nucleus.
    for n,ds in adopted.items():
        if any(s['nuclide']==n for s in states.values()):
            (OUT/'sources'/f'{ds["id"]}.txt').write_text('\n'.join(ds['lines']),encoding='utf-8')
            sources.append({'id':ds['id'],'title':ds['title'],'daughter':n,'revision':ds['revision'],'cutoff':ds['cutoff'],'url':nuclide_url(n),'sha256':ds['sha256'],'snapshot':'ensdf_261001.zip','raw_file':'sources/'+ds['id']+'.txt'})
    from supplement import append_literature
    append_literature(trs,states,sources,coverage,readj(DATA/'literature_evidence.json',[]))
    reviews=readj(DATA/'transition_review_overrides.json',{})
    for t in trs:
        review=reviews.get(t['id'])
        if review:
            t['flags']=list(dict.fromkeys(t['flags']+review['flags']))
            t['data_review']=review
        if 'expected_alpha' in t['flags']:t['observed_status']='expected_or_inferred_alpha'
        if 'unresolved_alpha_multiplet' in t['flags']:t['observed_status']='unresolved_alpha_multiplet'
        for prefix,key in [('initial','parent_state_id'),('final','final_state_id')]:
            st=states[t[key]]['structure']
            t[prefix+'_band_role']=st.get('band_role','unknown')
            t[prefix+'_band_role_basis']=st.get('band_role_basis','缺少可核实的带头/转动成员指认。')
            t[prefix+'_band_role_evidence']=st.get('band_role_evidence','unresolved')
    return trs,list(states.values()),sources,coverage,audits

def load_methods():
    modules={};out=[]
    for name,file,uses_l in METHODS:
        if file not in modules:
            spec=importlib.util.spec_from_file_location('hf_'+str(len(modules)),ROOT/'methods'/file);mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod);modules[file]=mod
        mod=modules[file]
        if name=='Royer':fn=lambda A,Z,Q,l,m=mod:m.logT_royer(A,Z,Q,m.case_from_ZN(Z,A-Z))
        elif name=='DZR':fn=lambda A,Z,Q,l,m=mod:m.logT_dzr(A,Z,Q,l,m.case_from_ZN(Z,A-Z))
        elif name=='Ismail2022':fn=lambda A,Z,Q,l,m=mod:m.ismail_log10T(A,Z,Q,l)
        elif name=='Qi2009_UDL':fn=lambda A,Z,Q,l,m=mod:m.qi_udl_log10T(A,Z,Q)[0]
        elif name=='Viola_Seaborg':fn=lambda A,Z,Q,l,m=mod:m.viola_seaborg_log10T(A,Z,Q)
        elif name=='Xu2022':fn=lambda A,Z,Q,l,m=mod:m.xu_log10T(A,Z,Q,l)[0]
        else:fn=lambda A,Z,Q,l,m=mod:m.calc_poenaru(A,Z,Q,m.PARAM_SETS['target'])['log10_T12a_Poenaru_s']
        out.append({'name':name,'version':'local_original','uses_l':uses_l,'fn':fn,'source_file':file,'sha256':hashlib.sha256((ROOT/'methods'/file).read_bytes()).hexdigest()})
    return out

def measurement_ok(t):
    return positive(t['T_partial_s']) and positive(t['Qalpha_MeV']) and t['preferred'] and not any(x in t['flags'] for x in ['qualified_measurement','estimated_Q','energy_balance_inconsistent','uncertain_alpha','expected_alpha','unresolved_alpha_multiplet','uncertain_final_state','unplaced_alpha','branch_gt_one','no_allowed_l','tentative_Jpi','multiple_Jpi'])

def log_error(t,fn,ell):
    """First-order asymmetric propagation; unknown errors remain explicitly incomplete.
    No model error is folded into measurement error. Chain bootstrap addresses
    clustering of observations, not propagation of correlated measurement errors.
    """
    q=t['Qalpha_MeV'];step=max(1e-6,q*1e-5)
    slope=-(fn(t['A'],t['Z'],q+step,ell)-fn(t['A'],t['Z'],q-step,ell))/(2*step)
    up=[];dn=[]
    for field,sgn in [('T_total_record',1),('b_alpha_record',-1),('I_record',-1)]:
        x=t[field];v=val(x)
        if not positive(v):continue
        a=x.get('plus');b=x.get('minus')
        if a is not None and b is not None:
            up.append(((a if sgn>0 else b)/(v*math.log(10)))**2);dn.append(((b if sgn>0 else a)/(v*math.log(10)))**2)
    if t['Q_err_plus'] is not None:up.append((slope*t['Q_err_plus'])**2)
    if t['Q_err_minus'] is not None:dn.append((slope*t['Q_err_minus'])**2)
    return math.sqrt(sum(dn)) if dn else None,math.sqrt(sum(up)) if up else None

def calc_results(trs,methods):
    rows=[]
    for t in trs:
        if not positive(t['Qalpha_MeV']):continue
        for m in methods:
            modes=[('l0' if m['uses_l'] else 'native',0,None)]
            if m['uses_l']:
                for i,c in enumerate(t['J_candidates']):
                    if c['lmin'] is not None:modes.append(('lmin',c['lmin'],i))
            for mode,ell,ci in modes:
                try:logT=m['fn'](t['A'],t['Z'],t['Qalpha_MeV'],ell)
                except (ValueError,OverflowError,ZeroDivisionError):continue
                h=math.log10(t['T_partial_s'])-logT if positive(t['T_partial_s']) else None
                minus,plus=log_error(t,m['fn'],ell) if h is not None else (None,None)
                qual=[]
                for field,sign in [('T_total_record',1),('b_alpha_record',-1),('I_record',-1),('Q_input_record',1)]:
                    q=t[field].get('qualifier')
                    if q in ['<','≤','>','≥']:qual.append(q if sign==1 else {'<':'>','≤':'≥','>':'<','≥':'≤'}[q])
                    elif q:qual.append(q)
                hfqual=qual[0] if len(set(qual))==1 else 'mixed_constraints' if qual else ''
                formal=mode=='l0' and bool(t['J_candidates']) and all(0 not in c['allowed'] for c in t['J_candidates'])
                certain_l=mode!='lmin' or (len(t['J_candidates'])==1 and not t['J_candidates'][0]['tentative'])
                status='main_candidate' if measurement_ok(t) and certain_l else 'sensitivity'
                zero=m['fn'](t['A'],t['Z'],t['Qalpha_MeV'],0)
                rows.append({'id':f'{t["id"]}:{m["name"]}:{mode}:{ci}','transition_id':t['id'],'method':m['name'],'version':m['version'],'mode':mode,'l':ell,'candidate_index':ci,'log10_Tcalc_s':logT,'Tcalc_s':10.**logT if -300<logT<300 else None,'log10_HF':h,'HF':10.**h if h is not None and -300<h<300 else None,'HF_qualifier':hfqual,'log10_HF_err_minus':minus,'log10_HF_err_plus':plus,'uncertainty_complete': 'incomplete_uncertainty' not in t['flags'],'uncertainty_model':'first-order asymmetric, input independence assumed; missing uncertainties not zero','model_systematic_sigma_log10':None,'model_uncertainty_status':'not_refitted_or_quantified','log10_R_l':logT-zero if m['uses_l'] else None,'R_l':10.**(logT-zero) if m['uses_l'] and abs(logT-zero)<300 else None,'formal_l0':formal,'sample_status':status})
    return rows

def ranges_for(trs,results,methods):
    ti={t['id']:t for t in trs};groups=defaultdict(list)
    for r in results:
        if r['log10_HF'] is None:continue
        t=ti[r['transition_id']]
        # Bounds and duplicate alternatives are not point samples in any range.
        if not t['preferred'] or r['HF_qualifier'] in ['<','≤','>','≥','mixed_constraints'] or any(f in t['flags'] for f in ['expected_alpha','unresolved_alpha_multiplet']):continue
        for label in t['labels']:
            for layer in ['independent','evaluated','all_records']:
                if layer=='independent' and (r['sample_status']!='main_candidate' or t['label_evidence'].get(label)!='independent'):continue
                if layer=='evaluated' and (r['sample_status']!='main_candidate' or label=='unknown'):continue
                # Do not count candidate scenarios as separate experimental observations.
                if r['mode']=='lmin' and len(t['J_candidates'])!=1:continue
                groups[(r['method'],r['version'],r['mode'],label,layer)].append((r,t))
    rng=np.random.default_rng(20261022);out=[]
    for m in methods:
        for mode in (['l0','lmin'] if m['uses_l'] else ['native']):
            for label in LABELS:
                for layer in ['independent','evaluated','all_records']:
                    items=groups.get((m['name'],m['version'],mode,label,layer),[])
                    byid={r['transition_id']:(r,t) for r,t in items};items=list(byid.values())
                    arr=np.array([r['log10_HF'] for r,t in items]);parents={t['parent'] for r,t in items};chains=defaultdict(list)
                    for r,t in items:chains[t['chain_id']].append(r['log10_HF'])
                    row={'method':m['name'],'version':m['version'],'mode':mode,'label':label,'evidence_layer':layer,'n_transitions':len(items),'n_parents':len(parents),'n_chains':len(chains),'status':'no_data' if not items else 'unknown_distribution' if label=='unknown' else 'small_sample' if len(parents)<10 else 'empirical_range','HF_p10':None,'HF_median':None,'HF_p90':None,'HF_min':None,'HF_max':None,'min_transition':None,'max_transition':None,'log10_p10_ci95':None,'log10_median_ci95':None,'log10_p90_ci95':None,'transition_ids':list(byid)}
                    if items:
                        q=np.quantile(10.**arr,[.1,.5,.9]);row.update({'HF_p10':float(q[0]),'HF_median':float(q[1]),'HF_p90':float(q[2]),'HF_min':float(10**arr.min()),'HF_max':float(10**arr.max()),'min_transition':items[int(arr.argmin())][0]['transition_id'],'max_transition':items[int(arr.argmax())][0]['transition_id']})
                        if len(parents)>=10 and len(chains)>=3:
                            blocks=list(chains.values());bs=[]
                            for _ in range(1000):
                                a=np.concatenate([blocks[i] for i in rng.integers(0,len(blocks),len(blocks))]);bs.append(np.log10(np.quantile(10.**a,[.1,.5,.9])))
                            ci=np.quantile(np.array(bs),[.025,.975],axis=0)
                            for i,k in enumerate(['p10','median','p90']):row[f'log10_{k}_ci95']=[float(x) for x in ci[:,i]]
                    out.append(row)
    return out

def database(tables):
    p=OUT/'hf_database.sqlite'
    if p.exists():p.unlink()
    db=sqlite3.connect(p)
    for name,rows in tables.items():
        if not rows:continue
        fields=list(dict.fromkeys(k for row in rows for k in row))
        def dtype(k):
            vs=[r.get(k) for r in rows if r.get(k) is not None]
            return 'INTEGER' if vs and all(isinstance(v,(bool,int)) for v in vs) else 'REAL' if vs and all(isinstance(v,(float,int)) for v in vs) else 'TEXT'
        cols=','.join('"'+k+'" '+dtype(k) for k in fields)
        db.execute(f'CREATE TABLE "{name}" ({cols})')
        db.executemany(f'INSERT INTO "{name}" VALUES ({",".join("?" for _ in fields)})',[[flat(r.get(k)) for k in fields] for r in rows])
    db.execute('CREATE INDEX idx_results_transition ON results(transition_id)');db.execute('CREATE INDEX idx_transition_nucleus ON transitions(Z,N)')
    db.execute('CREATE INDEX idx_results_method_mode ON results(method,mode)');db.commit();db.close()

def main():
    OUT.mkdir(parents=True,exist_ok=True);(OUT/'sources').mkdir(exist_ok=True)
    trs,states,sources,coverage,audits=make_transitions();methods=load_methods();results=calc_results(trs,methods);ranges=ranges_for(trs,results,methods)
    specs=[{k:v for k,v in m.items() if k!='fn'} for m in methods]
    evidence=[{'transition_id':t['id'],'label':label,'tier':tier,'parent_state_id':t['parent_state_id'],'final_state_id':t['final_state_id']} for t in trs for label,tier in t['label_evidence'].items()]
    role_audit=[{k:t[k] for k in ['id','parent','daughter','Ji','Jf','initial_nilsson','final_nilsson','initial_band_role','final_band_role','initial_band_role_evidence','final_band_role_evidence','initial_band_role_basis','final_band_role_basis','parent_state_id','final_state_id','labels','label_evidence','source_url']} for t in trs if t['initial_nilsson'] and t['initial_nilsson']==t['final_nilsson']]
    tables={'transitions':trs,'states':states,'sources':sources,'methods':specs,'results':results,'label_evidence':evidence,'hf_ranges':ranges,'coverage':coverage,'audit':audits,'literature_evidence':readj(DATA/'literature_evidence.json',[]),'formula_audit':readj(DATA/'formula_audit.json',[])}
    tables['bandhead_classification_audit']=role_audit
    tables['spin_flip_classification_audit']=[{k:t[k] for k in ['id','parent','daughter','Ji','Jf','initial_nilsson','final_nilsson','initial_spin_user','final_spin_user','initial_band_role','final_band_role','initial_band_role_evidence','final_band_role_evidence','initial_band_role_basis','final_band_role_basis','parent_state_id','final_state_id','labels','label_evidence','source_url']}|{'spin_flip_assigned':'spin_flip' in t['labels'],'reason':'两端均为带头且 Λ−K 改变。' if 'spin_flip' in t['labels'] else 'Λ−K 虽不同，但至少一端为非带头成员或带头身份未确定，不赋予 spin_flip。'} for t in trs if t['initial_spin_user'] is not None and t['final_spin_user'] is not None and t['initial_spin_user']!=t['final_spin_user']]
    for name,rows in tables.items():csvsave(OUT/(name+'.csv'),rows)
    database(tables)
    metadata={'title':'α 衰变 · HF 结构图谱','cutoff':'2026-10-22','snapshot':'ENSDF 2026-10-01','api_release':readj(RAW/'release.json',{}),'n_transitions':len(trs),'n_datasets':len(coverage),'n_states':len(states),'n_calculable':len({r['transition_id'] for r in results if r['HF'] is not None}),'n_results':len(results),'label_counts':dict(Counter(k for t in trs for k in t['labels'])),'main_label_counts':dict(Counter(k for t in trs for k,v in t['label_evidence'].items() if v=='independent' and measurement_ok(t))),'methods':specs,'labels':LABELS,'flags':dict(Counter(x for t in trs for x in t['flags'])),'limitations':['ENSDF snapshot enumerated comprehensively; bibliography updates are a separately audited supplement, not a claim of exhaustive post-evaluation literature coverage.','A/(A−4) recoil convention retained; no additional electron-screening correction silently applied.','HF ranges are empirical overlapping distributions, not unique wavefunction inversions.','Λ−K is the user spin convention; for pure single-qp Nilsson states its sign is opposite to conventional Σ=K−Λ.','Independent calibration requires explicit reviewed state evidence. Evaluated/unreviewed assignments remain sensitivity data.','Measurement errors use first-order asymmetric propagation with independent input errors; unspecified errors remain flagged.'], 'seed':20261022,'bootstrap_replicates':1000}
    metadata['label_policy']=LABEL_POLICY
    jsave(OUT/'metadata.json',metadata)
    payload={'meta':metadata,'transitions':trs,'states':{s['id']:s for s in states},'sources':{s['id']:s for s in sources},'results':results,'ranges':ranges,'method_audit':readj(DATA/'formula_audit.json',[])}
    jsave(OUT/'database.json',payload)
    template=(ROOT/'src'/'viewer.html').read_text() if (ROOT/'src'/'viewer.html').exists() else '<meta charset="utf-8"><h1>HF 数据库</h1><script>const DATA=__DATA__;</script>'
    (OUT/'index.html').write_text(template.replace('__DATA__',json.dumps(payload,ensure_ascii=False,separators=(',',':')).replace('</','<\\/')),encoding='utf-8')
    print(json.dumps(metadata,ensure_ascii=False,indent=2))

if __name__=='__main__':main()
