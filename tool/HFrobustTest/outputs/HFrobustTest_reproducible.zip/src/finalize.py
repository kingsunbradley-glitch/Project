"""Attach coverage audits and reproducibility metadata to all deliverables."""
import json,csv,sqlite3,hashlib,sys
from pathlib import Path
from collections import Counter,defaultdict
from build import ROOT,OUT,csvsave,jsave,LABELS

def readcsv(name):
 with (OUT/name).open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def main():
 p=json.loads((OUT/'database.json').read_text());meta=p['meta'];ev=json.loads((ROOT/'data/evaluation_crosscheck.json').read_text());le=json.loads((ROOT/'data/legacy_crosscheck.json').read_text())
 meta['quantile_definition']='HF-space linear quantiles (NumPy default); log10 axis for plots'
 meta['research_status']='working_research_database; exhaustive frozen ENSDF record enumeration, partial original-literature and independent-state evidence review'
 n_main=len({tid for g in p['ranges'] if g['evidence_layer']=='independent' for tid in g['transition_ids']})
 meta['n_main_transitions']=n_main
 meta['n_reviewed_states']=len(json.loads((ROOT/'data/state_evidence_overrides.json').read_text()))
 meta['coverage_audit']=f"NUBASE2020 含 α 分支的 386 个核态中，303 个能量匹配本库，48 个有母核但核态尚未唯一对应，35 个未在所用 ENSDF 快照找到 α 衰变数据集（包括估计和限值）。人工复核 {meta['n_reviewed_states']} 个核态的独立证据；目前主层仅 {n_main} 条跃迁，不能宣称已完成全部文献或建立稳定结构判别范围。"
 meta['limitations']=['逐条枚举 ENSDF 2026-10-01 快照，并补充选定原始实验；尚非截至2026-10-22所有论文的穷尽综述。',f'独立证据人工复核范围为17个核态，主标定仅{n_main}条跃迁。S标记与未分辨合峰不入逐线标定。空范围表示当前复核不足，不证明该类结构变化不存在。','35个NUBASE α核态没有对应ENSDF α数据集，另48个核态尚未唯一对应；未用基态质量差或总分支虚构逐跃迁观测。','Q采用本地反冲约定 Eα×A/(A−4)，与AME质量差单独交叉核查；未静默加入电子屏蔽修正。','输入误差按一阶非对称传播，缺失误差明确保留。公式系统误差未量化；链bootstrap描述样本聚类，不传播实验协方差。','除 same_intrinsic（同组态带头→带头）与 same_band（至少一端非带头）互斥外，其他标签可重叠。HF是公式相对实验的比值，不能唯一反演波函数或等同于某个形变参数。','Λ−K按用户约定；K取Nilsson轨道投影，不能用转动带成员的J代替。','Rurarz的原文记号A与Ad尚有待进一步核验；VS系数为偶偶基准，奇核为外推；Xu区域外C=0保留本地约定。']
 p['literature_evidence']=json.loads((ROOT/'data/literature_evidence.json').read_text());p['evaluation_crosscheck_summary']={k:v for k,v in ev.items() if k!='missing_parent_states'};p['legacy_crosscheck_summary']={k:v for k,v in le.items() if k!='crosschecks'}
 groups=defaultdict(list)
 for t in p['transitions']:groups[t['dataset_id']].append(t)
 norms=[]
 for k,ts in groups.items():
  norms.append({'dataset_id':k,'parent':ts[0]['parent'],'n_lines':len(ts),'n_missing_intensity':sum(t['I_alpha'] is None for t in ts),'sum_normalized_line_intensities':sum(t['I_alpha'] or 0 for t in ts),'alpha_normalization_factor':ts[0].get('alpha_normalization_record',{}).get('value',1),'note':'No forced sum-to-one correction. Limits, unplaced lines and unobserved branches retained; common normalization uncertainty not assumed independent across lines.'})
 csvsave(OUT/'branch_normalization_audit.csv',norms)
 additions={'ame_q_crosscheck':readcsv('ame_q_crosscheck.csv'),'nubase_alpha_inventory':readcsv('nubase_alpha_inventory.csv'),'legacy_crosscheck':readcsv('legacy_crosscheck.csv'),'formula_regression':readcsv('formula_regression.csv'),'branch_normalization_audit':readcsv('branch_normalization_audit.csv')}
 db=sqlite3.connect(OUT/'hf_database.sqlite')
 for name,rows in additions.items():
  db.execute(f'DROP TABLE IF EXISTS "{name}"')
  fields=list(rows[0]) if rows else []
  if not fields:continue
  db.execute(f'CREATE TABLE "{name}" ('+','.join('"'+k+'" TEXT' for k in fields)+')')
  db.executemany(f'INSERT INTO "{name}" VALUES ('+','.join('?' for _ in fields)+')',[[r[k] for k in fields] for r in rows])
 db.execute('CREATE TABLE IF NOT EXISTS metadata (key TEXT PRIMARY KEY,value TEXT)')
 db.executemany('INSERT OR REPLACE INTO metadata VALUES (?,?)',[(k,json.dumps(v,ensure_ascii=False)) for k,v in meta.items()]);db.commit();db.close()
 jsave(OUT/'metadata.json',meta);jsave(OUT/'database.json',p)
 template=(ROOT/'src/viewer.html').read_text();(OUT/'index.html').write_text(template.replace('__DATA__',json.dumps(p,ensure_ascii=False,separators=(',',':')).replace('</','<\\/')))
 # Every missing range receives an explicit, machine-readable reason.
 reasons=[]
 for r in p['ranges']:
  if r['n_transitions']:continue
  why='未建立具有独立于α-HF的逐跃迁结构证据、且数值输入合格的样本；目前人工复核范围有限。'
  if r['label']=='shape_changed':why='未复核到初末态均有独立形变证据且逐线α数据充分的样本；八极振动或理论β变化不能替代静态形变改变证据。'
  elif r['label']=='multi_qp_changed':why='未完成高K多准粒子α支路的初末组态、单线强度和独立指认联查；不按总J变化推断多准粒子改变。'
  elif r['label']=='configuration_mixing':why='251Fm有独立电磁强度支持混合解释，但对应暂定Jπ等数据条件未满足主层；其他混合指认尚在评估层。'
  elif r['label']=='unknown':why='unknown无独立结构标签，仅在全部记录层展示观测分布。'
  reasons.append({k:r[k] for k in ['method','version','mode','label','evidence_layer']}|{'reason':why})
 csvsave(OUT/'missing_range_reasons.csv',reasons)
 # Human-readable full nine-label matrices, separated by evidence and mode.
 def f(x):return '—' if x is None else f'{x:.4g}'
 lines=['# 七公式 × 九标签 HF 汇总','','数值来自 hf_ranges.csv；每行可用 transition_ids 追溯到 transitions.csv。P10–P90使用HF空间线性分位数。n为跃迁数／不同母核数。少于10个母核仅列跨度。上下限不进入点样本统计。','']
 lines.extend(['标签口径：same_intrinsic 仅为相同内禀准粒子组态的带头→带头；same_band 至少一端是非带头转动成员。两类互斥。spin_flip 也要求两端均为带头且 Λ−K 改变；parity_change 不限带头。带角色证据不足时不强制归类，详见 bandhead_classification_audit.csv 与 spin_flip_classification_audit.csv。',''])
 for layer in ['independent','evaluated','all_records']:
  lines.extend(['## '+{'independent':'独立证据主层','evaluated':'评估指认敏感性层','all_records':'全部点估计敏感性层'}[layer],''])
  for m in meta['methods']:
   for mode in (['l0','lmin'] if m['uses_l'] else ['native']):
    lines.extend([f"### {m['name']} / {mode} / local_original",'', '| 标签 | 中位数 | P10–P90 | 全部跨度 | n / 母核 | 状态 |','|---|---:|---|---|---:|---|'])
    for r in p['ranges']:
     if r['method']!=m['name'] or r['mode']!=mode or r['evidence_layer']!=layer:continue
     interval=f(r['HF_p10'])+' – '+f(r['HF_p90']) if r['n_parents']>=10 and r['label']!='unknown' else '—'
     lines.append(f"| {r['label']} | {f(r['HF_median'])} | {interval} | {f(r['HF_min'])} – {f(r['HF_max'])} | {r['n_transitions']} / {r['n_parents']} | {r['status']} |")
    lines.append('')
 (OUT/'HF_RANGE_SUMMARY.md').write_text('\n'.join(lines))
 manifest={'raw_files':{str(f.relative_to(ROOT)):hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted((ROOT/'data').rglob('*')) if f.is_file()},'method_files':{m['source_file']:m['sha256'] for m in meta['methods']},'snapshot':'ensdf_261001.zip','cutoff':'2026-10-22'}
 jsave(OUT/'provenance_manifest.json',manifest)
 print('Attached coverage/legacy audits, source manifest and all 270 range summaries.')
if __name__=='__main__':main()
