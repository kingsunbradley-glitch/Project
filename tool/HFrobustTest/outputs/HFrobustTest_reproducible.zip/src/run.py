"""Rebuild all delivered data/figures, offline after dependencies are installed."""
import subprocess,sys,shutil
from pathlib import Path
R=Path(__file__).resolve().parent
for f in ['build.py','legacy_crosscheck.py','evaluation_crosscheck.py','finalize.py','export_figures.py','pu239_audit.py','outlier_audit.py','test_physics.py']:
 subprocess.run([sys.executable,str(R/f)],check=True)
node=shutil.which('node')
if node:
 for f in ['test_viewer.cjs','test_outlier_audit.cjs']:subprocess.run([node,str(R/f)],check=True)
else:print('Node unavailable: run node src/test_viewer.cjs separately to check viewer parity.')

shutil.copy2(R.parent/'README.md',R.parent/'outputs/README.md')
