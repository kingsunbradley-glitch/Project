import unittest,math,json,sqlite3,hashlib
from pathlib import Path
import numpy as np
from ensdf import quantity,half_life,spins,allowed_l,nilsson,parse_decay
from build import ROOT,OUT,load_methods,ranges_for,calc_results,measurement_ok,band_role,match_level

class Physics(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.p=json.loads((OUT/'database.json').read_text());cls.ts=cls.p['transitions'];cls.rs=cls.p['results'];cls.mm=load_methods();cls.ti={t['id']:t for t in cls.ts}
 def test_quantity_and_units(self):
  self.assertEqual(quantity('9.30','7')['plus'],.07)
  self.assertAlmostEqual(half_life('12.6 MS','+37-23')['plus'],.0037)
  self.assertEqual(half_life('1.0 Y','2')['value'],31557600)
  self.assertEqual(quantity('3.2','LT')['qualifier'],'<')
  self.assertIsNone(quantity('UNKNOWN')['value'])
  self.assertEqual(quantity('0+X')['offset'],'X')
 def test_selection_rules(self):
  self.assertEqual(allowed_l(0,'+',0,'-'),[])
  self.assertEqual(allowed_l(.5,'+',.5,'-'),[1])
  self.assertEqual(allowed_l(2.5,'+',.5,'+'),[2])
  self.assertEqual(allowed_l(2.5,'-',2.5,'+'),[1,3,5])
  self.assertEqual(allowed_l(0,'+',.5,'+'),[])
  self.assertEqual(spins('(3/2,5/2)+'),[{'j':1.5,'parity':'+','tentative':True},{'j':2.5,'parity':'+','tentative':True}])
  self.assertEqual(spins('3/2'),[])
 def test_nilsson_spin_not_J(self):
  a=nilsson('1/2[530]')[0];self.assertEqual(a['k'],.5);self.assertEqual(a['sigma_user'],-.5)
  # 231Pa ground state has J=3/2 but K=1/2; never substitute J for K.
  st=[s for s in self.p['states'].values() if s['nuclide']=='231Pa' and s['energy']['value']==0 and s['structure']['nilsson']]
  self.assertTrue(st);self.assertEqual(st[0]['structure']['nilsson'][0]['k'],.5)
 def test_bandhead_definition(self):
  def role(jpi,orb='5/2[523]',band='5/2[523] band'):
   return band_role({'spins':spins(jpi)},nilsson(orb),band,{},'evaluated','evaluated')['band_role']
  self.assertEqual(role('5/2-'),'bandhead')
  self.assertEqual(role('7/2-'),'rotational_member')
  self.assertEqual(role('5/2-',band=''),'unknown')
  self.assertEqual(role('5/2-',band='K=5/2- band. Gamma transition to 5/2[523] state'),'unknown')
  self.assertEqual(role('5/2+'),'unknown')
  self.assertEqual(role('(5/2,7/2)-'),'unknown')
  self.assertEqual(role('3/2-','1/2[530]','1/2[530] ground band'),'rotational_member')
  intrinsic=[t for t in self.ts if 'same_intrinsic' in t['labels']]
  self.assertTrue(intrinsic)
  for t in intrinsic:
   self.assertEqual(t['initial_band_role'],'bandhead');self.assertEqual(t['final_band_role'],'bandhead')
   self.assertEqual(t['initial_nilsson'],t['final_nilsson']);self.assertNotIn('same_band',t['labels'])
  for t in self.ts:
   if 'same_band' in t['labels']:
    self.assertIn('rotational_member',[t['initial_band_role'],t['final_band_role']])
    self.assertNotIn('unknown',[t['initial_band_role'],t['final_band_role']])
   if t['parent']=='257Sg':self.assertNotIn('same_intrinsic',t['labels'])
  for state in self.p['states'].values():
   source=state['structure'].get('band_role_source_dataset')
   if source:self.assertEqual(source,state['source_dataset'])
 def test_no_double_branch_correction(self):
  for t in self.ts:
   if t['T_partial_s'] is not None:
    self.assertAlmostEqual(t['T_partial_s']*t['b_alpha']*t['I_alpha']/t['T_total_s'],1,places=12)
 def test_spin_flip_heads_and_parity_members(self):
  kept=[];excluded=[];parity_members=[]
  for t in self.ts:
   roles=[t['initial_band_role'],t['final_band_role']]
   a,b=t['initial_spin_user'],t['final_spin_user']
   expected=a is not None and b is not None and a!=b and roles==['bandhead','bandhead']
   self.assertEqual('spin_flip' in t['labels'],expected,t['id'])
   if expected:kept.append(t)
   elif a is not None and b is not None and a!=b:excluded.append(t)
   cc=t['J_candidates']
   parity_expected=bool(cc) and all(c['pi']!=c['pf'] for c in cc)
   self.assertEqual('parity_change' in t['labels'],parity_expected,t['id'])
   if parity_expected and 'rotational_member' in roles:parity_members.append(t)
  self.assertTrue(kept);self.assertTrue(excluded);self.assertTrue(parity_members)
 def test_explicit_alpha_normalization(self):
  ts=[t for t in self.ts if t['parent']=='255No']
  self.assertEqual(len(ts),10)
  self.assertAlmostEqual(sum(t['I_alpha'] for t in ts),.995247,places=6)
  for t in ts:self.assertAlmostEqual(t['I_alpha'],t['I_input_record']['value']*.297,places=12)
 def test_low_energy_isomer_matching(self):
  ground={'energy':quantity('0')};isomer={'energy':quantity('0.0760','4')}
  ds={'levels':[ground,isomer]}
  self.assertIs(match_level(ds,quantity('0.0765','4')),isomer)
  self.assertIs(match_level(ds,quantity('0')),ground)
  self.assertIsNone(match_level(ds,quantity('0.0765')))
  self.assertIsNone(match_level(ds,quantity('0.0765+X','4')))
  ds['levels'].append({'energy':quantity('0.0770','4')})
  self.assertIsNone(match_level(ds,quantity('0.0765','4')))
  ds['levels'][-1]={'energy':quantity('0.0755')}
  self.assertIsNone(match_level(ds,quantity('0.0765','4')))
 def test_pu239_favored_line(self):
  t=self.ti['ensdf-412f45083d69-a1']
  self.assertEqual((t['parent'],t['daughter']),('239Pu','235U'))
  self.assertEqual(t['Ef_keV'],.0765)
  self.assertEqual(t['final_adopted_energy_record']['value'],.0760)
  self.assertEqual(t['initial_nilsson'],t['final_nilsson'])
  self.assertEqual(t['final_nilsson'],'1/2[631]')
  self.assertIn('same_intrinsic',t['labels']);self.assertNotIn('same_band',t['labels'])
  self.assertNotEqual(t['label_evidence']['same_intrinsic'],'independent')
  norms=t['normalization_records']
  # Exercise the fixed-column N parser separately, using the frozen record.
  _,parsed,_=parse_decay({'lines':['header',norms[0]['raw_line']],'levels':[]})
  for n in [norms[0],parsed[0]]:
   self.assertEqual(n['nr']['value'],1e-6);self.assertEqual(n['nt']['value'],1e-6)
   self.assertEqual(n['br']['value'],1);self.assertIsNone(n['nb']['value'])
  self.assertEqual(t['I_input_record']['raw'],'70.77')
  self.assertAlmostEqual(t['br'],.7077,places=12)
  self.assertAlmostEqual(t['T_partial_s']/31557600,24110/.7077,places=8)
  self.assertAlmostEqual(t['Qalpha_MeV'],5.15659*239/235,places=12)
  self.assertEqual(t['J_candidates'][0]['lmin'],0)
  rs=[r for r in self.rs if r['transition_id']==t['id']]
  self.assertEqual(len(rs),10)
  self.assertTrue(all(.5<r['HF']<3 for r in rs))
 def test_method_regression(self):
  checks=json.loads((ROOT/'data/legacy_crosscheck.json').read_text())['numeric_regression']
  self.assertEqual(len(checks),6);self.assertTrue(all(c['passed_rounding_tolerance_1e_8'] for c in checks))
  roy=next(m for m in self.mm if m['name']=='Royer')
  ref=-25.31-1.1629*212**(1/6)*math.sqrt(84)+1.5864*84/math.sqrt(8.954)
  self.assertAlmostEqual(roy['fn'](212,84,8.954,0),ref,places=12)
  self.assertTrue(all(m['source_file']!='PoenaruMethod.py' for m in self.mm))
 def test_expected_and_unresolved_not_calibration(self):
  unresolved=self.ti['ensdf-ee6ecdf657a4-a7']
  self.assertIn('unresolved_alpha_multiplet',unresolved['flags'])
  self.assertFalse(measurement_ok(unresolved))
  self.assertAlmostEqual(unresolved['I_alpha'],.827)
  marked=[t for t in self.ts if 'expected_alpha' in t['flags']]
  self.assertTrue(marked)
  for t in marked:
   self.assertEqual(t['raw_alpha'].ljust(80)[79],'S')
   self.assertFalse(measurement_ok(t))
  excluded={t['id'] for t in marked}|{unresolved['id']}
  for g in self.p['ranges']:self.assertFalse(excluded.intersection(g['transition_ids']))
  cm=self.ti['ensdf-0cf17355062d-a7']
  self.assertIn('energy_balance_inconsistent',cm['flags']);self.assertFalse(measurement_ok(cm))
  good=self.ti['ensdf-0cf17355062d-a5']
  self.assertIn('derived_alpha_energy',good['flags']);self.assertTrue(measurement_ok(good))
  self.assertAlmostEqual(cm['Ealpha_MeV'],5.36622)
 def test_hf_angular_identity(self):
  zeros={(r['transition_id'],r['method']):r for r in self.rs if r['mode']=='l0'}
  for r in self.rs:
   if r['mode']=='lmin' and r['log10_HF'] is not None:
    z=zeros[(r['transition_id'],r['method'])]
    self.assertAlmostEqual(z['log10_HF']-r['log10_HF'],r['log10_R_l'],places=10)
  self.assertTrue(any(r['formal_l0'] for r in self.rs))
 def test_range_no_pseudoreplication(self):
  ri={(r['transition_id'],r['method'],r['mode']):r for r in self.rs}
  for x in self.p['ranges']:
   ids=x['transition_ids'];self.assertEqual(len(ids),len(set(ids)))
   self.assertEqual(len(ids),x['n_transitions'])
   for tid in ids:
    r=ri[(tid,x['method'],x['mode'])];t=self.ti[tid]
    self.assertNotIn(r['HF_qualifier'],['<','≤','>','≥','mixed_constraints']);self.assertTrue(t['preferred'])
    if x['evidence_layer']=='independent':
     self.assertEqual(t['label_evidence'][x['label']],'independent');self.assertTrue(measurement_ok(t))
    if x['mode']=='lmin':self.assertEqual(len(t['J_candidates']),1)
   if x['n_parents']<10:self.assertIsNone(x['log10_median_ci95'])
 def test_coverage_and_storage(self):
  self.assertEqual(set(t['Z'] for t in self.ts),set(range(89,119)))
  self.assertEqual(len(self.p['ranges']),270)
  db=sqlite3.connect(OUT/'hf_database.sqlite')
  self.assertEqual(db.execute('PRAGMA integrity_check').fetchone()[0],'ok')
  self.assertEqual(db.execute('select count(*) from results').fetchone()[0],len(self.rs))
  self.assertEqual(len(set(t['id'] for t in self.ts)),len(self.ts))
  self.assertTrue(all(r['transition_id'] in self.ti for r in self.rs))
  sg=next(t for t in self.ts if t['parent']=='257Sg');self.assertAlmostEqual(sg['T_partial_s'],.126)
  self.assertFalse(measurement_ok(sg));self.assertIsNone(sg['Ef_keV'])
 def test_offline_resources(self):
  h=(OUT/'index.html').read_text()
  self.assertNotIn('<script src=',h);self.assertNotIn('fetch(',h);self.assertNotIn('__DATA__',h)
if __name__=='__main__':unittest.main(verbosity=2)
