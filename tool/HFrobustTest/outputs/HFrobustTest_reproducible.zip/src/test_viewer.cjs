/* Run with Node, without a server or browser. Checks the embedded viewer's
 * statistical outputs against the independently generated frozen database.
 * DOM stubs exercise rendering logic only; visual/browser QA is separate.
 */
'use strict';
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const root = path.resolve(__dirname, '..');
const html = fs.readFileSync(path.join(__dirname, 'viewer.html'), 'utf8');
const input = JSON.parse(fs.readFileSync(path.join(root, 'outputs/database.json'), 'utf8'));
assert.equal(html.split('__DATA__').length - 1, 1, 'Template has exactly one embedding marker');
assert.equal(/<script[^>]+src\s*=/i.test(html), false, 'No remote JavaScript dependency');
assert.equal(/<link[^>]+href\s*=\s*["']https?:/i.test(html), false, 'No remote stylesheet dependency');
const script = html.match(/<script>([\s\S]*?)<\/script>/)[1]
  .replace('const DATA=__DATA__;', 'const DATA=globalThis.input;');
new vm.Script(script);
const elements = new Map();
function element(id) {
  if (!elements.has(id)) elements.set(id, {
    innerHTML: '', textContent: '', value: '', dataset: {}, handlers: {},
    classList: { add() {}, remove() {}, toggle() {}, contains() { return false; } },
    querySelectorAll() { return []; }, addEventListener(type, handler) { this.handlers[type] = handler; }, setAttribute() {}, focus() {}
  });
  return elements.get(id);
}
const context = {
  input, console, assert, setTimeout, clearTimeout, Blob, URL,
  document: {
    getElementById: element, querySelectorAll: () => [], addEventListener() {},
    body: { style: {} }, activeElement: element('start')
  }
};
vm.createContext(context);
vm.runInContext(script, context);
vm.runInContext(`
const same = (a,b,msg) => assert.equal(JSON.stringify(a),JSON.stringify(b),msg);
const approx = (a,b,msg) => {
  if(a===null||b===null) assert.equal(a,b,msg);
  else assert.ok(Math.abs(a-b)<=1e-10*Math.max(1,Math.abs(b)),msg+': '+a+' != '+b);
};
const defaultExpected = new Set(DATA.ranges.filter(r => r.method===S.method && r.mode===S.mode && r.evidence_layer==='independent').flatMap(r=>r.transition_ids));
same(currentRows.map(x=>x.t.id).sort(), [...defaultExpected].sort(), 'Default independent table exactly matches independently calibrated transitions');
console.log('Default independent layer:', currentRows.length, 'unique transitions');
let checked = 0;
for (const frozen of DATA.ranges) {
  Object.assign(S,{layer:frozen.evidence_layer,method:frozen.method,mode:frozen.mode,version:frozen.version,label:'',sameBandL:'',region:'',parity:'',zmin:89,zmax:118,nmin:N_MIN,nmax:N_MAX,search:'',nucleus:null,memberIds:null});
  const live = makeRange(frozen.method,frozen.mode,frozen.label);
  for(const key of ['n_transitions','n_parents','n_chains','status']) assert.equal(live[key],frozen[key],frozen.method+'/'+frozen.mode+'/'+frozen.label+'/'+frozen.evidence_layer+'/'+key);
  same(live.items.map(x=>x.t.id).sort(),[...frozen.transition_ids].sort(),'Exact range membership');
  for(const [liveKey,frozenKey] of [['log_min','HF_min'],['log_max','HF_max'],['log_p10','HF_p10'],['log_median','HF_median'],['log_p90','HF_p90']]) {
    approx(live[liveKey]===null?null:10**live[liveKey],frozen[frozenKey],'Frozen vs dynamic '+frozenKey);
  }
  assert.ok(live.frozen, 'Full-scope bootstrap metadata available');
  checked++;
}
console.log('Frozen versus dynamic ranges:', checked, 'groups; all memberships, counts, status and quantiles agree');
let renders=0;
for(const layer of ['independent','evaluated','all_records']) {
  S.layer=layer;
  for(const method of methods) {
    S.method=method.name;
    S.mode=method.uses_l?'lmin':'native';
    for(const tab of ['atlas','ranges','angular','about']) {
      S.tab=tab;render();
      assert.ok($('view').innerHTML.length>100,'View produces content');
      renders++;
    }
  }
}
console.log('Render paths:', renders, '(4 views × 7 methods × 3 evidence layers)');
Object.assign(S,{method:methods[0].name,mode:methods[0].uses_l?'l0':'native',layer:'all_records',nucleus:null,memberIds:null,search:'',label:'',sameBandL:'',region:'',parity:'',zmin:89,zmax:118,nmin:N_MIN,nmax:N_MAX});
const allRows=tableRows();
assert.equal(allRows.length,trs.length,'All-record table retains all transitions, including missing data');
assert.ok($('nmin').handlers.change && $('nmax').handlers.change,'Both neutron inputs are wired');
const chosenN=trs.find(t=>t.N>N_MIN&&t.N<N_MAX).N;
$('nmin').value=chosenN;$('nmin').handlers.change();
$('nmax').value=chosenN;$('nmax').handlers.change();
assert.equal(S.nmin,chosenN,'N lower bound accepts parent neutron number');
assert.equal(S.nmax,chosenN,'N upper bound accepts parent neutron number');
assert.equal(currentRows.length,trs.filter(t=>t.N===chosenN).length,'Rendered table count follows neutron filter');
assert.ok(currentRows.every(({t})=>t.N===chosenN),'Transition table contains only selected parent N');
for(const label of labels){const group=makeRange(S.method,S.mode,label);assert.equal(group.frozen,null,'N-filtered range omits full-scope bootstrap CI');assert.ok(group.items.every(({t})=>t.N===chosenN),'N filter applies to every HF range')}
$('reset').onclick();
assert.equal(S.nmin,N_MIN,'Reset restores minimum parent N');
assert.equal(S.nmax,N_MAX,'Reset restores maximum parent N');
S.layer='all_records';
console.log('Parent neutron-number filtering, ranges and reset passed:',chosenN);
S.layer='evaluated';S.tab='ranges';render();
assert.ok($('sameBandL').handlers.change,'Same-band angular momentum selector is wired');
const bandBefore=makeRange(S.method,S.mode,'same_band');
const otherBefore=makeRange(S.method,S.mode,'same_intrinsic');
const bandL=bandBefore.items[0].t.J_candidates[0].lmin;
assert.ok(new Set(bandBefore.items.map(x=>x.t.J_candidates[0].lmin)).size>1,'Fixture spans multiple allowed l values');
assert.ok($('sameBandL').innerHTML.includes('lₘᵢₙ = '+bandL),'Selector includes observed l value');
$('sameBandL').value=String(bandL);$('sameBandL').handlers.change();
const bandAfter=makeRange(S.method,S.mode,'same_band');
assert.ok(bandAfter.n_transitions>0&&bandAfter.n_transitions<bandBefore.n_transitions,'Same-band range responds to l selection');
assert.ok(bandAfter.items.every(x=>x.t.J_candidates[0].lmin===bandL),'Same-band range contains only selected l');
assert.equal(bandAfter.frozen,null,'Same-band l subset does not reuse full-scope bootstrap');
same(makeRange(S.method,S.mode,'same_intrinsic').items.map(x=>x.t.id),otherBefore.items.map(x=>x.t.id),'Other labels retain their members');
assert.ok(makeRange(S.method,S.mode,'same_intrinsic').frozen,'Unaffected label keeps its full-scope bootstrap');
assert.equal((rangeSVG(currentRanges).match(/中位 HF/g)||[]).length,labels.length,'Every full-size label row displays a central HF value or missing marker');
assert.equal((rangeSVG(currentRanges,true).match(/中位 HF/g)||[]).length,labels.length,'Compact comparison chart also labels central HF');
assert.ok(rangeSVG(currentRanges).includes('中位 HF '+fmt(10**bandAfter.log_median,3)),'Chart median annotation matches selected data');
assert.ok(rangeSVG(currentRanges).includes('same_band · lₘᵢₙ = '+bandL),'Exportable SVG records the active l selector');
S.label='same_band';render();
assert.ok(currentRows.length>0&&currentRows.every(({t})=>t.labels.includes('same_band')&&t.J_candidates[0].lmin===bandL),'Same-band transition table follows l selector');
$('reset').onclick();
assert.equal(S.sameBandL,'','Reset clears same-band l selector');
S.layer='all_records';
console.log('Same-band l selection and nine-label median annotations passed:',bandL);
S.layer='evaluated';S.tab='ranges';render();
const nilssonBefore=makeRange(S.method,S.mode,'nilsson_changed');
const bandUnfiltered=makeRange(S.method,S.mode,'same_band');
const nilssonL=nilssonBefore.items.find(x=>x.t.J_candidates[0].lmin>0).t.J_candidates[0].lmin;
assert.ok($('nilssonL').innerHTML.includes('lₘᵢₙ = '+nilssonL),'Nilsson selector offers observed nonzero l');
$('nilssonL').value=String(nilssonL);$('nilssonL').handlers.change();
const nilssonAfter=makeRange(S.method,S.mode,'nilsson_changed');
assert.ok(nilssonAfter.n_transitions>0&&nilssonAfter.n_transitions<nilssonBefore.n_transitions,'Nilsson range responds to l selection');
assert.ok(nilssonAfter.items.every(x=>x.t.J_candidates.length===1&&x.t.J_candidates[0].lmin===nilssonL),'Nilsson membership follows selected l');
assert.equal(nilssonAfter.frozen,null,'Nilsson subset does not reuse full-scope bootstrap');
same(makeRange(S.method,S.mode,'same_band').items.map(x=>x.t.id),bandUnfiltered.items.map(x=>x.t.id),'Nilsson filter does not alter same-band range');
assert.ok(makeRange(S.method,S.mode,'same_band').frozen,'Unfiltered same-band range retains frozen bootstrap');
assert.equal(labelLMatches({J_candidates:[]},'nilsson_changed'),false,'Unknown l excluded from specified-l subset');
assert.equal(labelLMatches({J_candidates:[{lmin:nilssonL},{lmin:nilssonL}]},'nilsson_changed'),false,'Multiple candidates not collapsed into a certain l');
$('sameBandL').value=String(bandL);$('sameBandL').handlers.change();
same(makeRange(S.method,S.mode,'nilsson_changed').items.map(x=>x.t.id),nilssonAfter.items.map(x=>x.t.id),'Independent l selectors do not cross-filter');
const svg=rangeSVG(currentRanges,true);
assert.ok(svg.includes('nilsson_changed · lₘᵢₙ = '+nilssonL)&&svg.includes('same_band · lₘᵢₙ = '+bandL),'SVG preserves both selector values');
assert.ok(svg.includes('中位 HF '+fmt(10**nilssonAfter.log_median,3)),'Nilsson median is recomputed from selected members');
const originalBlob=Blob,originalSaveBlob=saveBlob;let exported;
Blob=class {constructor(parts){this.content=parts.join('')}};saveBlob=blob=>{exported=blob.content};
exportCSV('ranges');
assert.ok(exported.includes('nilsson_changed_lmin')&&exported.includes('not_recomputed_for_subset'),'Range export carries l filter and subset bootstrap status');
S.label='nilsson_changed';S.tab='atlas';render();
assert.ok(currentRows.length>0&&currentRows.every(({t})=>t.labels.includes('nilsson_changed')&&t.J_candidates.length===1&&t.J_candidates[0].lmin===nilssonL),'Nilsson table follows l selector');
exportCSV('transitions');assert.ok(exported.includes('selected_nilsson_changed_lmin'),'Transition CSV retains selected Nilsson l');
Blob=originalBlob;saveBlob=originalSaveBlob;
S.method='DZR';S.mode='lmin';S.tab='angular';render();
assert.ok(currentRows.every(({r})=>r?.l===nilssonL),'Nilsson l filter also applies with centrifugal correction');
$('reset').onclick();assert.equal(S.nilssonL,'','Reset clears Nilsson selector');assert.equal(S.sameBandL,'','Reset clears both selectors');
S.layer='all_records';
console.log('Nilsson l selection, independent scopes, corrected mode and exports passed:',nilssonL);
S.layer='all_records';render();
for(const id of ['ensdf-ee6ecdf657a4-a7','ensdf-412f45083d69-a16','ensdf-412f45083d69-a41']) {
 const t=ti.get(id);assert.ok(tableRows().some(x=>x.t.id===id),'Flagged record remains in full table');
 assert.ok(t.labels.every(k=>!labelEligible(t,oneResult(t),k)),'Expected or unresolved input is not a single-line range observation');
 openDetail(id);assert.ok($('detail').innerHTML.includes('不作为已分辨实测单线HF进入范围统计'),'Detail explains reference-only HF');
}
S.layer='evaluated';render();
assert.ok(!tableRows().some(x=>x.t.id==='ensdf-0cf17355062d-a7'),'Calculated-Q example absent from evaluated calibration');
S.layer='all_records';render();
assert.ok(tableRows().some(x=>x.t.id==='ensdf-0cf17355062d-a7'),'Calculated-Q example retained for sensitivity review');
const limits=allRows.filter(({r})=>r&&['<','≤','>','≥','mixed_constraints'].includes(r.HF_qualifier));
assert.ok(limits.length>0,'Limit observations remain available in table');
for(const label of labels) {
  const group=makeRange(S.method,S.mode,label);
  assert.ok(group.items.every(({t,r})=>t.preferred&&!['<','≤','>','≥','mixed_constraints'].includes(r.HF_qualifier)),'Limits and duplicate alternatives are excluded from point-sample ranges');
}
console.log('All-record table includes',limits.length,'limit records; ranges exclude them');
S.nucleus=trs.find(t=>t.labels.includes('nilsson_changed')).parent;
for(const label of labels) {
  const group=makeRange(S.method,S.mode,label);
  assert.equal(group.frozen,null,'Filtered subset never reuses full-scope bootstrap CI');
  assert.ok(group.items.every(x=>x.t.parent===S.nucleus),'Nucleus selection applies to dynamic ranges');
}
S.nucleus=null;S.method='DZR';S.mode='lmin';
for(const label of labels) assert.ok(makeRange(S.method,S.mode,label).items.every(x=>x.t.J_candidates.length===1),'Multiple l scenarios never become independent observations');
S.layer='evaluated';S.tab='ranges';S.compare=true;render();
assert.equal(currentRanges.length,methods.length*labels.length,'Comparison includes every formula and label');
$('hfQuery').value='12.5';queryHF();
assert.ok($('queryResult').innerHTML.includes('HF = 12.5'),'HF query renders selected numerical value');
$('hfQuery').value='0';queryHF();
assert.ok($('queryResult').innerHTML.includes('大于零'),'Nonpositive HF rejected');
for(const t of [trs.find(t=>t.initial_nilsson),trs.find(t=>t.J_candidates.length>1),trs.find(t=>!t.J_candidates.length)]) {
  if(t) {openDetail(t.id);assert.ok($('detail').innerHTML.includes(t.id),'Detail contains traceable transition ID');}
}
openDetail('ensdf-412f45083d69-a1');
for(const text of ['0.0765','0.0760','70.77','1/2[631]','仅用于 γ 强度，不乘入 α 的 IA。']) {
  assert.ok($('detail').innerHTML.includes(text),'Pu-239 detail preserves normalization and isomer provenance: '+text);
}
assert.equal(esc('<img onerror="test">'),'&lt;img onerror=&quot;test&quot;&gt;','Source text safely escaped');
assert.equal(csvCell('=1+1').charCodeAt(1),39,'CSV protects formula-like strings');
console.log('Filtered subsets, candidate deduplication, comparison, query, detail and escaping passed');
`, context);
console.log('PASS: Offline viewer logic verified. Browser rendering and downloads require separate UI QA.');
