"""AME Q consistency and NUBASE coverage inventory, never implicit line insertion."""
import json,re,csv,math,hashlib
from pathlib import Path
from collections import Counter
from build import ROOT,OUT,csvsave
from ensdf import SYMBOLS
RAW=ROOT/'data/raw'
def num(s):
 try:return float(s.strip().replace('#','.'))
 except ValueError:return None

def main():
 p=json.loads((OUT/'database.json').read_text());ts=p['transitions'];qs={}
 for s in (RAW/'rct1.mas20.txt').read_text().splitlines():
  try:a=int(s[1:4]);z=int(s[8:11])
  except ValueError:continue
  if not 87<=z<=118:continue
  v=s[56:68];u=s[68:78]
  qs[(a,z)]={'value':num(v),'error':num(u),'estimated':'#' in v+u,'raw':v.strip()}
 comparisons=[]
 for t in ts:
  g=qs.get((t['A'],t['Z']))
  if not g or g['value'] is None:continue
  valid=t['Ei_keV'] is not None and t['Ef_keV'] is not None and '+' not in t['Ei_raw'] and '+' not in t['Ef_raw']
  qif=(g['value']+t['Ei_keV']-t['Ef_keV'])/1000 if valid else None
  comparisons.append({'transition_id':t['id'],'parent':t['parent'],'AME2020_Qgs_MeV':g['value']/1000,'AME2020_Qgs_error_MeV':g['error']/1000 if g['error'] is not None else None,'AME2020_estimated':g['estimated'],'Qif_mass_levels_MeV':qif,'Qif_selected_MeV':t['Qalpha_MeV'],'selected_minus_mass_levels_keV':1000*(t['Qalpha_MeV']-qif) if t['Qalpha_MeV'] is not None and qif is not None else None,'status':'comparison_only_not_replacement' if valid else 'unresolved_excitation_offset','note':'Different evaluation dates, recoil/electron conventions and level assignments can contribute. No uncorrelated mass-error sum substituted for AME reaction-Q uncertainty.'})
 catalog=[]
 for s in (RAW/'nubase_4.mas20.txt').read_text().splitlines():
  if s.startswith('#'):continue
  try:a=int(s[:3]);z=int(s[4:7]);idx=int(s[7])
  except ValueError:continue
  if not 89<=z<=118:continue
  decay=s[119:209].strip();m=re.search(r'(?:^|;)A(?=[=~<>?])[^;]*',decay)
  if not m:continue
  name=f'{a}{SYMBOLS[z-1]}';cand=[t for t in ts if t['parent']==name];e=num(s[42:54]) if idx else 0.
  # This table inventories missing resolution; it never manufactures a daughter state.
  ids=[t['id'] for t in cand if e is not None and t['Ei_keV'] is not None and abs(e-t['Ei_keV'])<.1 and '+' not in t['Ei_raw']]
  catalog.append({'parent':name,'Z':z,'A':a,'state_index':idx,'isomer_symbol':s[16:17].strip(),'excitation_raw_keV':s[42:54].strip(),'excitation_keV':e,'half_life_raw':s[69:80].strip(),'Jpi_raw':s[88:102].strip(),'decay_modes':decay,'alpha_branch_raw':m[0].lstrip(';'),'estimated_or_limit_alpha':bool(re.search('[#<>?~]',m[0])),'matched_transition_ids':ids,'status':'state_energy_match' if ids else 'parent_present_state_unresolved' if cand else 'no_ENSDF_alpha_dataset_in_snapshot','source':'NUBASE2020','raw_line':s})
 csvsave(OUT/'ame_q_crosscheck.csv',comparisons);csvsave(OUT/'nubase_alpha_inventory.csv',catalog)
 summary={'AME_source':'https://amdc.impcas.ac.cn/masstables/Ame2020/rct1.mas20','NUBASE_source':'https://amdc.impcas.ac.cn/masstables/Ame2020/nubase_4.mas20','AME_citation':'M. Wang et al., Chinese Phys. C 45, 030003 (2021)','NUBASE_citation':'F. G. Kondev et al., Chinese Phys. C 45, 030001 (2021)','n_Q_comparisons':len(comparisons),'n_NUBASE_alpha_states':len(catalog),'coverage_counts':dict(Counter(x['status'] for x in catalog)),'missing_parent_states':[x for x in catalog if x['status']=='no_ENSDF_alpha_dataset_in_snapshot'],'limitations':'NUBASE inventory includes estimated branches and limits; an absent ENSDF alpha dataset does not establish no alpha decay. These unresolved entries are retained in a separate audit, not converted to invented resolved transitions. Post-2020 states may be absent from NUBASE.'}
 (ROOT/'data/evaluation_crosscheck.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2));(OUT/'evaluation_crosscheck.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
 print(json.dumps({k:v for k,v in summary.items() if k!='missing_parent_states'},ensure_ascii=False,indent=2))
if __name__=='__main__':main()
