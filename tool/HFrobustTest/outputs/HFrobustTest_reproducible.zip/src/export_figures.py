"""Publication-style standalone figures from exactly the frozen range table."""
import json,math,os
from pathlib import Path
os.environ.setdefault('MPLCONFIGDIR',str(Path(__file__).resolve().parents[1]/'.cache/matplotlib'))
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
R=Path(__file__).resolve().parents[1];O=R/'outputs';P=json.loads((O/'database.json').read_text());M=P['meta']['methods'];L=list(P['meta']['labels']);ts={t['id']:t for t in P['transitions']};rr={(r['transition_id'],r['method'],r['mode']):r for r in P['results']};out=O/'figures';out.mkdir(exist_ok=True)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'svg.fonttype':'none','axes.spines.top':False,'axes.spines.right':False})
for layer in ['independent','evaluated','all_records']:
 for angular in ['reference','selection_rule']:
  fig,axes=plt.subplots(1,7,figsize=(18,7),sharey=True,sharex=True)
  for ax,m in zip(axes,M):
   mode=('l0' if angular=='reference' else 'lmin') if m['uses_l'] else 'native'
   for y,label in enumerate(L):
    row=next(x for x in P['ranges'] if x['method']==m['name'] and x['mode']==mode and x['label']==label and x['evidence_layer']==layer)
    n=row['n_transitions'];np_=row['n_parents'];col='#0e797d' if layer=='independent' else '#b66a22'
    if not n:
     ax.text(.02,y,'no reviewed data',transform=ax.get_yaxis_transform(),fontsize=7,color='#89929c',va='center');continue
    vals=[rr[(tid,m['name'],mode)]['log10_HF'] for tid in row['transition_ids']]
    jitter=np.random.default_rng(43).uniform(-.14,.14,len(vals))
    ax.scatter(vals,np.array([y]*len(vals))+jitter,s=5,alpha=.25,color=col,zorder=2)
    ax.plot(np.log10([row['HF_min'],row['HF_max']]),[y,y],color=col,alpha=.55,lw=1)
    if np_>=10 and label!='unknown':ax.plot(np.log10([row['HF_p10'],row['HF_p90']]),[y,y],color=col,lw=5,solid_capstyle='round')
    ax.plot(math.log10(row['HF_median']),y,'o',ms=4,color=col)
    ax.text(.98,y-.23,f'{n} / {np_}; med={row["HF_median"]:.3g}',transform=ax.get_yaxis_transform(),ha='right',fontsize=7,color='#606975')
   ax.set_title(m['name'].replace('_',' ')+'\n'+mode,fontsize=10);ax.set_xlabel(r'$\log_{10}(HF)$');ax.grid(axis='x',alpha=.15);ax.set_axisbelow(True);ax.axvline(0,c='#b8c0c5',lw=.6)
   ax.set_ylim(8.6,-.6)
  axes[0].set_yticks(range(9),[{'same_intrinsic':'same intrinsic\n(head to head)','same_band':'same band\n(non-head involved)','spin_flip':'spin flip\n(head to head)'}.get(s,s.replace('_',' ')) for s in L]);fig.suptitle('Alpha-transition HF by structure label | '+layer+' | '+angular,fontsize=16,x=.16,ha='left')
  note='Dots: transitions; line: full span; thick line: P10–P90 only for >=10 parents; marker: HF median. Counts: transitions / parents.\nsame_intrinsic: head to head only; same_band: non-head involved. spin_flip: heads only; parity_change: all roles.\nOther labels may overlap. Bounds/duplicates, expected lines and unresolved multiplets excluded. Independent layer has insufficient parent counts for stable calibration.\nENSDF 2026-10-01 + selected literature audited 2026-10-22; all_records includes tentative and approximate inputs. No unique wavefunction inference.'
  fig.text(.16,.02,note,fontsize=9,color='#465360');fig.subplots_adjust(left=.16,right=.99,top=.85,bottom=.18,wspace=.18)
  name=f'hf_ranges_{layer}_{angular}'
  for ext in ['svg','png']:fig.savefig(out/(name+'.'+ext),dpi=220,facecolor='white')
  plt.close(fig)
print('12 SVG/PNG figures exported')
