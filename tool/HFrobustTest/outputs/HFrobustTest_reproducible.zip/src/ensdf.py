"""Small, auditable reader for the ENSDF P/N/L/A records used in this study.

Raw text is always retained. Unsupported values remain missing, never zero.
Fixed columns follow the NNDC ENSDF format, 2026-10-01 archive.
"""
import re, math, zipfile, hashlib
from collections import defaultdict
from pathlib import Path

SYMBOLS=('H He Li Be B C N O F Ne Na Mg Al Si P S Cl Ar K Ca Sc Ti V Cr Mn Fe Co Ni Cu Zn Ga Ge As Se Br Kr Rb Sr Y Zr Nb Mo Tc Ru Rh Pd Ag Cd In Sn Sb Te I Xe Cs Ba La Ce Pr Nd Pm Sm Eu Gd Tb Dy Ho Er Tm Yb Lu Hf Ta W Re Os Ir Pt Au Hg Tl Pb Bi Po At Rn Fr Ra Ac Th Pa U Np Pu Am Cm Bk Cf Es Fm Md No Lr Rf Db Sg Bh Hs Mt Ds Rg Cn Nh Fl Mc Lv Ts Og').split()
ZS={s.upper():i+1 for i,s in enumerate(SYMBOLS)}
UNITS={'Y':31557600.,'D':86400.,'H':3600.,'M':60.,'S':1.,'MS':1e-3,'US':1e-6,'NS':1e-9,'PS':1e-12,'FS':1e-15,'AS':1e-18}

def nucleus(s):
    m=re.fullmatch(r'\s*(\d{3})([A-Za-z]{1,2}|\d{2})\s*',s)
    if not m:return None
    a=int(m[1]); k=m[2].upper();z=ZS.get(k,100+int(k) if k.isdigit() else 0)
    if not 1<=z<=118:return None
    return {'a':a,'z':z,'n':a-z,'name':f'{a}{SYMBOLS[z-1]}','symbol':SYMBOLS[z-1]}

def quantity(v,err='',factor=1.):
    raw=v.strip(); err=err.strip(); q={'raw':raw,'error_raw':err,'value':None,'minus':None,'plus':None,'qualifier':'','offset':None}
    if not raw:return q
    clean=raw.replace('D','E')
    m=re.fullmatch(r'([+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:E[+-]?\d+)?)(?:\+([A-Z]))?',clean,re.I)
    if not m:
        q['qualifier']='unparsed';return q
    try:val=float(m[1])*factor
    except ValueError:return q
    if not math.isfinite(val):return q
    q['value']=val;q['offset']=m[2]
    if m[2]:q['qualifier']='offset'
    if err in ['LT','LE','GT','GE','AP','CA','SY']:
        q['qualifier']={'LT':'<','LE':'≤','GT':'>','GE':'≥','AP':'≈','CA':'calculated','SY':'systematics'}[err];return q
    mantissa,_,exp=m[1].upper().partition('E')
    scale=10.**((int(exp) if exp else 0)-(len(mantissa.split('.')[1]) if '.' in mantissa else 0))*factor
    if err.isdigit():q['minus']=q['plus']=int(err)*scale
    else:
        plus=re.search(r'\+(\d+)',err);minus=re.search(r'-(\d+)',err)
        if plus and minus:q['plus']=int(plus[1])*scale;q['minus']=int(minus[1])*scale
        elif err:q['qualifier']='unparsed_uncertainty'
    return q

def half_life(v,err=''):
    m=re.fullmatch(r'\s*([0-9.+\-Ee]+)\s+([A-Za-z]+)\s*',v)
    if not m or m[2].upper() not in UNITS:return quantity('')|{'raw':v.strip(),'error_raw':err.strip(),'qualifier':'unparsed' if v.strip() else ''}
    return quantity(m[1],err,UNITS[m[2].upper()])|{'raw':v.strip(),'unit':m[2]}

def spins(raw):
    """Return finite candidate pairs; never infer a missing parity."""
    s=raw.strip().replace(' ',''); tentative=bool(re.search(r'[()#?]|TO|LT|GT|LE|GE',s))
    if not s:return []
    if re.search(r'(?i)TO|LT|GT|LE|GE|HIGH|LOW|J',s):return []
    s=s.replace('(','').replace(')','').replace('#','').replace('?','')
    tokens=s.split(','); lastpar=tokens[-1][-1:] if tokens[-1][-1:] in ['+','-'] else None
    out=[]
    for t in tokens:
        m=re.fullmatch(r'(\d+)(?:/(\d+))?([+-])?',t)
        if not m:continue
        j=int(m[1])/(int(m[2]) if m[2] else 1);p=m[3] or lastpar
        if p and abs(j*2-round(j*2))<1e-9:out.append({'j':j,'parity':p,'tentative':tentative or len(tokens)>1})
    return out

def allowed_l(ji,pi,jf,pf):
    if abs((ji-jf)-round(ji-jf))>1e-9:return []
    return [l for l in range(math.ceil(abs(ji-jf)-1e-10),math.floor(ji+jf+1e-10)+1) if (1 if l%2==0 else -1)==(1 if pi==pf else -1)]

def comments_text(lines):
    return '\n'.join(l[9:].rstrip() for l in lines)

def parse_levels(lines):
    levels=[]; current=None;band_comments={};general=[];last_tag='';last_band=None
    for line in lines:
        line=line.ljust(80)
        if line[5:9]=='  L ':
            last_tag=''
            current={'index':len(levels),'energy':quantity(line[9:19],line[19:21]),'jpi_raw':line[21:39].strip(),'half_life':half_life(line[39:49],line[49:55]),'band_flags':line[76:77].strip(),'existence':line[79:80].strip(),'comments':[],'spin_comments':[],'continuations':[],'raw_line':line.rstrip()}
            current['spins']=spins(current['jpi_raw']);levels.append(current)
        elif line[6:8].lower()=='cl':
            text=line[9:].rstrip();key=line[9:19].strip()
            # ENSDF table footnotes: E(A), BAND(A), etc.
            fm=re.match(r'(?:E|BAND)\(([A-Za-z0-9])\)\s*\$?\s*(.*)',text)
            if current is None:
                general.append(text)
                if fm:
                    last_band=fm[1];band_comments.setdefault(last_band,[]).append(fm[2])
                elif line[5]!=' ' and last_band:band_comments[last_band].append(text)
                else:last_band=None
            else:
                current['comments'].append(text)
                if line[5]==' ':last_tag='J' if re.match(r'^J(?:\$|\s)',text) else ''
                if last_tag=='J':current['spin_comments'].append(text)
        elif line[7]=='L' and line[5]!=' ' and current is not None:
            current['continuations'].append(line[9:].rstrip())
            bm=re.search(r'(?:BAND|FLAG)=([A-Za-z0-9])',line)
            if bm and bm[1] not in current['band_flags']:current['band_flags']+=bm[1]
    for l in levels:
        l['band_description']=' . '.join(' '.join(band_comments.get(flag,[])) for flag in l['band_flags'] if band_comments.get(flag))
    return levels,band_comments,general

def read_archive(path):
    datasets=[]
    with zipfile.ZipFile(path) as z:
        for name in z.namelist():
            if not re.search(r'ensdf\.\d{3}$',name) or int(name[-3:])<190:continue
            for block in re.split(r'\n\s*\n',z.read(name).decode('utf-8','replace')):
                lines=block.splitlines()
                if not lines:continue
                header=lines[0].ljust(80);nu=nucleus(header[:5])
                if not nu or not 87<=nu['z']<=118:continue
                title=header[9:39].strip()
                if not (title.startswith('ADOPTED LEVELS') or ' A DECAY' in title):continue
                ident=hashlib.sha256((header[:39]).encode()).hexdigest()[:12]
                levels,bands,general=parse_levels(lines[1:])
                d={'id':'ensdf-'+ident,'title':title,'nuclide':nu,'header':header.rstrip(),'revision':header[74:80].strip(),'lines':lines,'levels':levels,'bands':bands,'general_level_comments':general,'sha256':hashlib.sha256(block.encode()).hexdigest(),'mass_file':name,'cutoff':None}
                dates=re.findall(r'CUT=([^$\n]+)',block)
                if dates:d['cutoff']=dates[0].strip()
                datasets.append(d)
    return datasets

def parse_decay(d):
    parents=[];norms=[];alphas=[];current_level=None;current_alpha=None;level_idx=-1
    for line in d['lines'][1:]:
        line=line.ljust(80)
        if line[5:9]=='  P ':
            parents.append({'nuclide':nucleus(line[:5]),'energy':quantity(line[9:19],line[19:21]),'jpi_raw':line[21:39].strip(),'spins':spins(line[21:39]),'half_life':half_life(line[39:49],line[49:55]),'q_ground':quantity(line[64:74],line[74:76],.001),'raw_line':line.rstrip(),'comments':[]})
        elif line[6:8].lower()=='cp' and parents:parents[-1]['comments'].append(line[9:].rstrip())
        elif line[5:9]=='  N ':
            # NR/NT normalize photon/total gamma-transition intensities. They
            # are retained for audit and never multiplied into alpha IA.
            norms.append({'nr':quantity(line[9:19],line[19:21]),'nt':quantity(line[21:29],line[29:31]),'br':quantity(line[31:39],line[39:41]),'nb':quantity(line[41:49],line[49:55]),'raw_line':line.rstrip()})
        elif line[5:9]=='  L ':
            level_idx+=1;current_level=d['levels'][level_idx];current_alpha=None
        elif line[5:9]=='  A ':
            current_alpha={'index':len(alphas),'energy':quantity(line[9:19],line[19:21],.001),'intensity':quantity(line[21:29],line[29:31],.01),'evaluated_hf':quantity(line[31:39],line[39:41]),'level':current_level,'existence':line[79:80].strip(),'comments':[],'raw_line':line.rstrip()};alphas.append(current_alpha)
        elif line[6:8].lower()=='ca' and current_alpha is not None:
            current_alpha['comments'].append(line[9:].rstrip())
    return parents,norms,alphas

def nilsson(text):
    """Extract explicit single-particle Omega[N nz Lambda] labels only."""
    text=text.replace('$','').replace('\\','').replace('{','').replace('}','')
    # Handles ENSDF 5/2[523] and rendered 5/2^- [523].
    found=[]
    for m in re.finditer(r'(?<!\d)(\d+/2|\d+)\s*(?:\^?[+-])?\s*\[\s*([4-9])\s*([0-9])\s*([0-9])\s*\]',text):
        k=float(m[1].split('/')[0])/(2 if '/' in m[1] else 1);N,nz,lam=map(int,m.group(2,3,4))
        if abs(abs(k-lam)-.5)>1e-8:continue
        v={'orbital':f'{m[1]}[{N}{nz}{lam}]','k':k,'N':N,'nz':nz,'lambda':lam,'sigma_user':lam-k,'parity':'+' if N%2==0 else '-'}
        if v not in found:found.append(v)
    return found

def is_limit(q):return q.get('qualifier') in ['<','≤','>','≥']
