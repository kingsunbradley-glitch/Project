"""Audit a frozen pre-review set; never remove points just for being outliers.

Selection is per label and formula, native local versions, evaluated layer,
full Z/N and no l filter. Independent arithmetic below does not call adapters.
"""
import json,math,html,sqlite3,re
from collections import Counter,defaultdict
from build import ROOT,OUT,csvsave,jsave

def independent_logt(A,Z,Q,method):
    if method=='Viola_Seaborg':return (1.787*Z-21.40)/math.sqrt(Q)-.2549*Z-28.42
    if method=='Royer':
        abc={(0,0):(-25.31,-1.1629,1.5864),(0,1):(-26.65,-1.0859,1.5848),(1,0):(-25.68,-1.1423,1.5920),(1,1):(-29.48,-1.1130,1.6971)}
        a,b,c=abc[Z%2,(A-Z)%2]
        return a+b*A**(1/6)*math.sqrt(Z)+c*Z/math.sqrt(Q)
    def reduced(v,edges):
        lo,hi=next((a,b) for a,b in zip(edges,edges[1:]) if a<v<=b)
        return (v-lo)/(hi-lo)
    y=reduced(A-Z,[51,83,127,185,229,283]);z=reduced(Z,[51,83,115,121,173,185])
    x=.4253*Q*(1.5874+(A-4)**(1/3))/(Z-2)
    k=2.52956*(Z-2)*math.sqrt((A-4)/(A*Q))*(math.acos(math.sqrt(x))-math.sqrt(x*(1-x)))
    return (.988662+.016314*y+.020433*z+.027896*y*y-.003033*y*z-.003033*z*z)*k/math.log(10)-20.446

def select(baseline):
    methods=baseline['methods'];ri={(r['transition_id'],r['method']):r for r in baseline['results']};groups=defaultdict(dict)
    for g in baseline['ranges']:groups[g['label']][g['method']]=g
    selected=[]
    for label,gs in groups.items():
        for tid in gs[methods[0]]['transition_ids']:
            values={m:ri[tid,m]['HF'] for m in methods}
            sides={m:'low' if values[m]<gs[m]['HF_p10'] else 'high' if values[m]>gs[m]['HF_p90'] else 'inside' for m in methods}
            if 'inside' in sides.values():continue
            thresholds={m:{k:gs[m][k] for k in ['HF_p10','HF_median','HF_p90','n_parents','n_transitions']} for m in methods}
            selected.append({'transition_id':tid,'label':label,'sides':sides,'HF':values,'baseline_thresholds':thresholds,'small_sample':gs[methods[0]]['n_parents']<10})
    return selected

def main():
    p=json.loads((OUT/'database.json').read_text());base=json.loads((ROOT/'data/outlier_audit_baseline.json').read_text());selected=select(base)
    ti={t['id']:t for t in p['transitions']};ri={(r['transition_id'],r['method'],r['mode']):r for r in p['results']};notes=json.loads((ROOT/'data/outlier_review_notes.json').read_text())
    ids=sorted({s['transition_id'] for s in selected},key=lambda tid:(ti[tid]['Z'],ti[tid]['A'],ti[tid]['Ef_keV'] or 0))
    rows=[]
    for tid in ids:
        t=ti[tid];raw=(OUT/'sources'/f"{t['dataset_id']}.txt").read_text().splitlines();idx=int(tid.rsplit('-a',1)[1]);seen=-1;level=None;alpha=None
        for n,line in enumerate(raw):
            line=line.ljust(80)
            if line[5:9]=='  L ':level=line
            if line[5:9]=='  A ':
                seen+=1
                if seen==idx:alpha=line;line_no=n+1;break
        parents=[l.ljust(80) for l in raw if l[5:9]=='  P '];norms=[l.ljust(80) for l in raw if l[5:9]=='  N ']
        checks={}
        checks['raw_alpha_exact']=alpha.rstrip()==t['raw_alpha']
        checks['daughter_level_identity']=level[9:19].strip()==t['Ef_raw'] and re.sub(r'\s','',level[:5]).lower()==t['daughter'].lower()
        checks['parent_identity']=len(parents)==1 and re.sub(r'\s','',parents[0][:5]).lower()==t['parent'].lower() and parents[0][9:19].strip()==t['Ei_raw']
        checks['alpha_percent_to_fraction']=math.isclose(float(alpha[21:29])/100,t['I_input_record']['value'],rel_tol=1e-12)
        nb=float(norms[0][41:49]) if len(norms)==1 and norms[0][41:49].strip() else 1.
        br=float(norms[0][31:39]) if len(norms)==1 and norms[0][31:39].strip() else None
        checks['alpha_not_gamma_normalization']=math.isclose(t['I_alpha'],float(alpha[21:29])/100*nb,rel_tol=1e-12)
        checks['total_alpha_branch']=br is not None and math.isclose(br,t['b_alpha'],rel_tol=1e-12)
        checks['partial_half_life']=math.isclose(t['T_total_s']/(t['I_alpha']*t['b_alpha']),t['T_partial_s'],rel_tol=1e-12)
        checks['recoil_energy']=math.isclose(float(alpha[9:19])/1000*t['A']/(t['A']-4),t['Qalpha_MeV'],rel_tol=1e-12)
        rec=t['T_total_record'];mt=re.fullmatch(r'([\d.E+\-]+)\s+(Y|D|H|M|S|MS|US|NS)',rec['raw']);units={'Y':31557600,'D':86400,'H':3600,'M':60,'S':1,'MS':.001,'US':1e-6,'NS':1e-9}
        checks['half_life_units']=bool(mt) and math.isclose(float(mt[1])*units[mt[2]],t['T_total_s'],rel_tol=1e-12)
        state=p['states'][t['parent_state_id']];sraw=(OUT/'sources'/f"{state['source_dataset']}.txt").read_text().splitlines()
        checks['half_life_source']=any(l.ljust(80)[39:49].strip()==rec['raw'] and l.ljust(80)[49:55].strip()==rec['error_raw'] and l[21:39].strip()==t['Ji'] and re.sub(r'\s','',l[:5]).lower()==t['parent'].lower() for l in sraw if l[5:9] in ['  L ','  P '])
        fs=p['states'][t['final_state_id']];fsraw=(OUT/'sources'/f"{fs['source_dataset']}.txt").read_text().splitlines();fe=t.get('final_adopted_energy_record');eraw=fe['raw'] if fe else t['Ef_raw']
        checks['final_spin_source']=any(l[9:19].strip()==eraw and l[21:39].strip()==t['Jf'] for l in fsraw if l[5:9]=='  L ')
        errors={m:independent_logt(t['A'],t['Z'],t['Qalpha_MeV'],m)-ri[tid,m,'native']['log10_Tcalc_s'] for m in base['methods']}
        checks['three_formula_arithmetic']=all(abs(v)<1e-10 for v in errors.values())
        checks['HF_definition']=all(math.isclose(10**(math.log10(t['T_partial_s'])-independent_logt(t['A'],t['Z'],t['Qalpha_MeV'],m)),ri[tid,m,'native']['HF'],rel_tol=1e-10) for m in base['methods'])
        own=[s for s in selected if s['transition_id']==tid]
        exclusion=[f for f in ['expected_alpha','unresolved_alpha_multiplet','energy_balance_inconsistent'] if f in t['flags']]
        qlevel=t['Q_ground_MeV']+(t['Ei_keV']-t['Ef_keV'])/1000
        sensitivity={m:10**(independent_logt(t['A'],t['Z'],t['Qalpha_MeV'],m)-independent_logt(t['A'],t['Z'],qlevel,m)) for m in base['methods']}
        result={m:ri[tid,m,'native'] for m in base['methods']}
        # These are known-input first-order errors only, not a new confidence interval.
        robust=[]
        for g in own:
            robust.append(all((result[m]['log10_HF']-result[m]['log10_HF_err_minus']>math.log10(g['baseline_thresholds'][m]['HF_p90']) if g['sides'][m]=='high' else result[m]['log10_HF']+result[m]['log10_HF_err_plus']<math.log10(g['baseline_thresholds'][m]['HF_p10'])) if result[m]['log10_HF_err_minus'] is not None and result[m]['log10_HF_err_plus'] is not None else False for m in base['methods']))
        row={'transition_id':tid,'parent':t['parent'],'daughter':t['daughter'],'Ef_keV':t['Ef_keV'],'Ji':t['Ji'],'Jf':t['Jf'],'initial_nilsson':t['initial_nilsson'],'final_nilsson':t['final_nilsson'],'lmin':t['J_candidates'][0]['lmin'],'outlier_labels':[s['label'] for s in own],'side_by_label':{s['label']:s['sides'] for s in own},'baseline_thresholds':{s['label']:s['baseline_thresholds'] for s in own},'small_sample_labels':[s['label'] for s in own if s['small_sample']],
             'HF_VS':result['Viola_Seaborg']['HF'],'HF_Rurarz':result['E_Rurarz']['HF'],'HF_Royer':result['Royer']['HF'],'ENSDF_HF_reference':t['evaluated_HF_reference_only']['value'],'I_alpha_percent_raw':alpha[21:29].strip(),'I_alpha_fraction':t['I_alpha'],'b_alpha':t['b_alpha'],'T_total_s':t['T_total_s'],'T_partial_s':t['T_partial_s'],'Ealpha_MeV':t['Ealpha_MeV'],'Qalpha_MeV':t['Qalpha_MeV'],'Q_from_levels_MeV':qlevel,'Q_energy_balance_difference_keV':1000*(t['Qalpha_MeV']-qlevel),'HF_ratio_if_using_level_Q':sensitivity,'DZR_R_l_reference':ri.get((tid,'DZR','lmin'),{}).get('R_l'),
             'checks':checks,'arithmetic_max_delta_log10T':max(abs(v) for v in errors.values()),'known_error_still_outside_all_three_by_label':dict(zip([s['label'] for s in own],robust)),'experimental_error_complete':'incomplete_uncertainty' not in t['flags'],'exclusion_flags_added':exclusion,'review_status':'需降为敏感性/非单线记录' if exclusion else '未发现转录或换算错误（冻结ENSDF级）','review_notes':notes[t['parent']],'flags':t['flags'],'source_url':t['source_url'],'source_file':f"sources/{t['dataset_id']}.txt",'source_line':line_no,'raw_alpha':t['raw_alpha'],'alpha_comments':t['comments'],'final_band':fs['structure']['band']}
        rows.append(row)
    failures=[{'id':r['transition_id'],'failed':[k for k,v in r['checks'].items() if not v]} for r in rows if not all(r['checks'].values())]
    summary={'selection':base['scope'],'n_transitions':len(rows),'n_label_memberships':len(selected),'n_parents':len({r['parent'] for r in rows}),'counts_by_label':dict(Counter(s['label'] for s in selected)),'n_reviewed_outliers_reclassified':sum(bool(r['exclusion_flags_added']) for r in rows),'global_expected_alpha_records':sum('expected_alpha' in t['flags'] for t in p['transitions']),'global_reviewed_calculated_Q_records':sum('data_review' in t and 'derived_alpha_energy' in t['flags'] for t in p['transitions']),'checks_failed':failures,'n_main_after_review':p['meta']['n_main_transitions'],'scope_limit':'Frozen ENSDF record and local-formula arithmetic audit; not an independent remeasurement or exhaustive original-experiment review. Rurarz original A/Ad convention remains unresolved.'}
    csvsave(OUT/'outlier_audit.csv',rows);csvsave(OUT/'outlier_label_memberships.csv',selected);jsave(OUT/'outlier_audit.json',{'summary':summary,'rows':rows})
    db=sqlite3.connect(OUT/'hf_database.sqlite');db.execute('DROP TABLE IF EXISTS outlier_audit');db.execute('CREATE TABLE outlier_audit(transition_id TEXT PRIMARY KEY, parent TEXT, review_status TEXT, details_json TEXT)');db.executemany('INSERT INTO outlier_audit VALUES(?,?,?,?)',[(r['transition_id'],r['parent'],r['review_status'],json.dumps(r,ensure_ascii=False)) for r in rows]);db.commit();db.close()
    text=['# VS / E. Rurarz / Royer：共同越界数据核查','',f"评估指认层、全核区、无l筛选；按修订前每个结构标签各自的P10–P90取三式共同越界的交集。冻结候选为{len(rows)}条跃迁、{len(selected)}个跃迁—标签项、{summary['n_parents']}种母核。P10–P90是中央80%经验范围，不是中心值的置信区间；不以越界作为删除理由。",'',
          '## 已确认的记录状态问题','',
          '- 233U→229Th：0-keV条目的82.7%包括基态与8.355734-eV异能态，不能作为单独基态分支。保留数值为合峰参考，退出逐跃迁范围。',
          '- 239Pu→235U：338.52、821.25-keV条目为ENSDF S标记的预期/推断α支路，不能当作已直接观测、已分辨α线进入标定；IA不是γ归一化误乘。',
          '- 242Cm→238Pu：763.22-keV线的Eα来自能量关系推算，当前Eα与P.Q−Ef相差约4.07 keV。标记energy_balance_inconsistent，保留原值于敏感性层；计算能量本身不自动判错。详表给出改用能级Q的影响，仅作敏感性比较。',
          f"- 同类规则覆盖全库：{summary['global_expected_alpha_records']}条S记录获得明确状态；242Cm的{summary['global_reviewed_calculated_Q_records']}条推算能量记录继承来源标记，其中303.42和763.22-keV两条能量关系明显不一致，退出主/评估层；其余不因推算来源而被自动排除。数值未因越界而调整。独立主标定从3条变为{summary['n_main_after_review']}条（233U合峰退出）。",'',
          '## 数值与解释','',
          f"逐项核对原始A/L/P/N记录、百分数、总α分支、半衰期单位、末态自旋来源、反冲Q与部分半衰期；独立重写三式数值表达式复算。失败项：{len(failures)}。这仅证明与冻结源和本地约定一致，不保证实验值、组态纯度或原论文记号完全正确。",'',
          '- 251Es基态为same_intrinsic唯一共同高端点，bα相对误差40%；计入已知实验误差后与部分公式经验边界重叠，不能仅据点估计越界称为错误。',
          '- 229Th基态IA文献存在0.05%与0.01%分歧，HF会差5倍；原始采用值未改动。',
          '- 大HF常伴弱α支路及较大l；低HF也可能伴Coriolis混合或集体八极带。三式无显式l项，HF不是剥离离心阻碍后的纯内禀量。DZR修正倍数仅供另一模型下的比较，不能直接套入三式。',
          '- configuration_mixing仅4个母核，为小样本；逐线表保留其尾部，不声称是稳定异常阈值。',
          '- VS本地四系数源于偶偶核拟合，奇核使用属于外推；Royer四奇偶参数复算一致；Rurarz本地算式复算一致，但原论文A与Ad的记号仍待核准，未声称原式已完全验证。',
          '- 249Bk低端支路的原注释轨道记号与Adopted带描述不一致，已单列待回原论文核验，未按HF强行改标签。','',
          '## 全部候选（修订前固定选择）','','| 母核→子核 | Ef keV | 标签 | lmin | HF VS | HF Rurarz | HF Royer | 核查结果 |','|---|---:|---|---:|---:|---:|---:|---|']
    for r in rows:text.append(f"| {r['parent']}→{r['daughter']} | {r['Ef_keV']:g} | {', '.join(r['outlier_labels'])} | {r['lmin']} | {r['HF_VS']:.5g} | {r['HF_Rurarz']:.5g} | {r['HF_Royer']:.5g} | {r['review_status']}；[原始A记录]({r['source_file']}) |")
    text+=['','详见交互表 OUTLIER_AUDIT.html、逐线CSV outlier_audit.csv、逐标签阈值表 outlier_label_memberships.csv。审计保留修订前阈值，不通过反复删除尾部点制造稳定分布。','',
           '来源：[ENSDF手册第12节](https://www.nndc.bnl.gov/ensdf/ensdf-manual.pdf)、[Royer与Zhang原文](https://harvest.aps.org/v2/journals/articles/10.1103/PhysRevC.77.037602/fulltext)、[VS参数出处](https://periodic-table.com/Preprints/2004/160(E7-2004-160).pdf)。各跃迁的冻结源与在线评估表链接保存在CSV中；本次未重读46条跃迁的全部原始实验论文。','']
    (OUT/'OUTLIER_AUDIT.md').write_text('\n'.join(text))
    page='''<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>三式共同越界核查</title><style>body{font:15px system-ui,sans-serif;color:#15364a;background:#f6f8fa;margin:30px}h1{font-size:26px}p{max-width:1100px;line-height:1.7}input,select{padding:9px;margin:8px}table{border-collapse:collapse;width:100%;background:white}th,td{padding:10px;border-bottom:1px solid #dde4ea;text-align:left;vertical-align:top}th{position:sticky;top:0;background:#e9f1f5}td{font-size:13px}details{max-width:650px}pre{white-space:pre-wrap;overflow-wrap:anywhere}.warn{color:#a44d18}a{color:#007c87}.box{background:#fff;padding:14px;border-left:4px solid #007c87}</style><h1>VS · E. Rurarz · Royer：共同越界核查</h1><p>评估指认层，全核区，无 l 筛选。按每个标签修订前的 P10–P90 取三式共同越界的交集：<b>46 条跃迁 / 56 个跃迁—标签项</b>。中央80%经验范围不是置信区间；越界不是判错依据。此表固定原候选，避免修订范围后移动核查目标。</p><p class="box">4条候选需要修正统计资格：233U合峰1条、239Pu的S标记2条、242Cm能量关系不一致1条。其余未发现转录/换算错误，但保留实验分歧、模型适用性和结构证据限制。全库HF数值未因越界而改写。</p><p><a href="index.html">返回HF图谱</a> · <a href="OUTLIER_AUDIT.md">核查说明</a> · <a href="outlier_audit.csv" download>逐线CSV</a> · <a href="outlier_label_memberships.csv" download>原始判定阈值</a></p><input id="q" placeholder="母核、末态、轨道或标签"><select id="status"><option value="">全部结论</option><option value="review">需调整统计资格</option><option value="retained">保留但附限制</option></select><span id="count"></span><table><thead><tr><th>跃迁 / 末态 keV</th><th>标签 / lmin</th><th>HF VS / Rurarz / Royer</th><th>核查与证据</th></tr></thead><tbody id="rows"></tbody></table><script>const DATA=__AUDIT__;const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));function render(){const q=document.getElementById('q').value.toLowerCase(),s=document.getElementById('status').value;const rows=DATA.rows.filter(r=>JSON.stringify([r.parent,r.daughter,r.Ef_keV,r.initial_nilsson,r.final_nilsson,r.outlier_labels]).toLowerCase().includes(q)&&(!s||(s==='review')===!!r.exclusion_flags_added.length));document.getElementById('count').textContent=rows.length+' 条';document.getElementById('rows').innerHTML=rows.map(r=>`<tr><td><b>${esc(r.parent)} → ${esc(r.daughter)}</b><br>Ef=${r.Ef_keV}<br>${esc(r.Ji)} → ${esc(r.Jf)}<br>${esc(r.initial_nilsson)} → ${esc(r.final_nilsson)}</td><td>${esc(r.outlier_labels.join(', '))}<br>lmin=${r.lmin}${r.small_sample_labels.length?'<br>含小样本类别':''}</td><td>${[r.HF_VS,r.HF_Rurarz,r.HF_Royer].map(x=>x.toPrecision(5)).join('<br>')}<br><small>ENSDF参考：${esc(r.ENSDF_HF_reference)}</small></td><td><b class="${r.exclusion_flags_added.length?'warn':''}">${esc(r.review_status)}</b><p>${esc(r.review_notes)}</p><details><summary>原始量、阈值与逐项检查</summary><pre>${esc(JSON.stringify(r,null,2))}</pre></details><a href="${esc(r.source_file)}">冻结原文 · 第${r.source_line}行</a> · <a href="${esc(r.source_url)}">在线ENSDF</a></td></tr>`).join('')}document.getElementById('q').oninput=render;document.getElementById('status').onchange=render;render();</script>'''
    (OUT/'OUTLIER_AUDIT.html').write_text(page.replace('__AUDIT__',json.dumps({'summary':summary,'rows':rows},ensure_ascii=False).replace('</','<\\/')))
    print(json.dumps(summary,ensure_ascii=False,indent=2))
    if failures:raise AssertionError('Audit found source/arithmetic failures; review before delivery')

if __name__=='__main__':main()
